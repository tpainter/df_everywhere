#include "sdlmodule.h"

#define DEC_CONST(x) \
	tmp = PyInt_FromLong(SDL_##x); \
	PyDict_SetItemString(module_dict, #x, tmp); \
	Py_DECREF(tmp)

#define DEC_CONSTK(x) \
	tmp = PyInt_FromLong(SDL##x); \
	PyDict_SetItemString(module_dict, #x, tmp); \
	Py_DECREF(tmp)

#define DEC_CONSTN(x) \
	tmp = PyInt_FromLong(x); \
	PyDict_SetItemString(module_dict, #x, tmp); \
	Py_DECREF(tmp)

#define INIT_TYPE(x) \
	(##x##_Type.ob_type) = &PyType_Type;

#ifndef min
	#define min(x,y) x < y ? x : y
#endif

#ifndef max
	#define max(x,y) x > y ? x : y
#endif

#define SDL_INIT_CHECK \
	if(!sdl_is_initialized) \
	{ \
		PyErr_SetString(PyExc_RuntimeError, "SDL has not been initialized."); \
		return NULL; \
	}

#define VIDEO_INIT_CHECK \
	if(!video_is_initialized) \
	{ \
		PyErr_SetString(PyExc_RuntimeError, \
			"The video subsystem has not been initialized."); \
		return NULL; \
	}

#define EVENT_INIT_CHECK VIDEO_INIT_CHECK

#define CDROM_INIT_CHECK \
	if(!cdrom_is_initialized) \
	{ \
		PyErr_SetString(PyExc_RuntimeError, \
			"The cdrom subsystem has not been initialized."); \
		return NULL; \
	}

#define JOY_INIT_CHECK \
	if(!joy_is_initialized) \
	{ \
		PyErr_SetString(PyExc_RuntimeError, \
			"The joystick subsystem has not been initialized."); \
		return NULL; \
	}

#define AUDIO_INIT_CHECK \
	if(!audio_is_initialized) \
	{ \
		PyErr_SetString(PyExc_RuntimeError, \
			"The audio subsystem has not been initialized."); \
		return NULL; \
	}

void initsdl()
{
	PyObject* module;
	PyObject* module_dict;

	PyObject* tmp;
	
	/* Initialized *_Type */

	INIT_TYPE(Surface);
	INIT_TYPE(CD);
	INIT_TYPE(Event);
	INIT_TYPE(Joystick);
	INIT_TYPE(AudioDev);
	INIT_TYPE(Sound);
	INIT_TYPE(Music);
	INIT_TYPE(Font);

	/* Initialize module */

	module = Py_InitModule3(sdl__name__, sdl__builtins__, sdl__doc__);
	module_dict = PyModule_GetDict(module);

	/* Register the module, if compiled on Win32 */

	#ifdef WIN32
		SDL_RegisterApp("PySDL", CS_BYTEALIGNCLIENT, GetModuleHandle(NULL));
	#endif

	/* Add various #defines to the sdl package's global namespace */

	DEC_CONST(INIT_VIDEO);
	DEC_CONST(INIT_AUDIO);
	DEC_CONST(INIT_CDROM);
	DEC_CONST(INIT_JOYSTICK);
	DEC_CONST(INIT_NOPARACHUTE);
	DEC_CONST(INIT_EVERYTHING);

	DEC_CONST(SWSURFACE);
	DEC_CONST(HWSURFACE);
	DEC_CONST(RESIZABLE);
	DEC_CONST(ASYNCBLIT);
	DEC_CONST(OPENGL);
	DEC_CONST(ANYFORMAT);
	DEC_CONST(HWPALETTE);
	DEC_CONST(DOUBLEBUF);
	DEC_CONST(FULLSCREEN);
	DEC_CONST(HWACCEL);
	DEC_CONST(SRCCOLORKEY);
	DEC_CONST(RLEACCELOK);
	DEC_CONST(RLEACCEL);
	DEC_CONST(SRCALPHA);
	DEC_CONST(SRCCLIPPING);
	DEC_CONST(PREALLOC);
	DEC_CONST(GL_RED_SIZE);
	DEC_CONST(GL_GREEN_SIZE);
	DEC_CONST(GL_BLUE_SIZE);
	DEC_CONST(GL_ALPHA_SIZE);
	DEC_CONST(GL_BUFFER_SIZE);
	DEC_CONST(GL_DOUBLEBUFFER);
	DEC_CONST(GL_DEPTH_SIZE);
	DEC_CONST(GL_STENCIL_SIZE);
	DEC_CONST(GL_ACCUM_RED_SIZE);
	DEC_CONST(GL_ACCUM_GREEN_SIZE);
	DEC_CONST(GL_ACCUM_BLUE_SIZE);
	DEC_CONST(GL_ACCUM_ALPHA_SIZE);

	DEC_CONSTN(INFO_HW_A);
	DEC_CONSTN(INFO_WM_A);
	DEC_CONSTN(INFO_BLT_HW);
	DEC_CONSTN(INFO_BLT_HW_CC);
	DEC_CONSTN(INFO_BLT_HW_A);
	DEC_CONSTN(INFO_BLT_SW);
	DEC_CONSTN(INFO_BLT_SW_CC);
	DEC_CONSTN(INFO_BLT_SW_A);
	DEC_CONSTN(INFO_BLT_FILL);
	DEC_CONSTN(INFO_MEM);

	DEC_CONST(GRAB_QUERY);
	DEC_CONST(GRAB_OFF);
	DEC_CONST(GRAB_ON);


	DEC_CONSTN(AUDIO_U8);
	DEC_CONSTN(AUDIO_S8);
	DEC_CONSTN(AUDIO_U16LSB);
	DEC_CONSTN(AUDIO_S16LSB);
	DEC_CONSTN(AUDIO_U16MSB);
	DEC_CONSTN(AUDIO_S16MSB);
	DEC_CONSTN(AUDIO_U16);
	DEC_CONSTN(AUDIO_S16);
	DEC_CONSTN(AUDIO_U16SYS);
	DEC_CONSTN(AUDIO_S16SYS);

	DEC_CONSTN(CD_TRAYEMPTY);
	DEC_CONSTN(CD_STOPPED);
	DEC_CONSTN(CD_PLAYING);
	DEC_CONSTN(CD_PAUSED);
	DEC_CONSTN(CD_ERROR);
	
	DEC_CONST(AUDIO_TRACK);
	DEC_CONST(DATA_TRACK);

	DEC_CONST(NOEVENT);
	DEC_CONST(ACTIVEEVENT);
	DEC_CONST(KEYDOWN);
	DEC_CONST(KEYUP);
	DEC_CONST(MOUSEMOTION);
	DEC_CONST(MOUSEBUTTONDOWN);
	DEC_CONST(MOUSEBUTTONUP);
	DEC_CONST(JOYAXISMOTION);
	DEC_CONST(JOYBALLMOTION);
	DEC_CONST(JOYHATMOTION);
	DEC_CONST(JOYBUTTONDOWN);
	DEC_CONST(JOYBUTTONUP);
	DEC_CONST(VIDEORESIZE);
	DEC_CONST(QUIT);
	DEC_CONST(SYSWMEVENT);
	DEC_CONST(USEREVENT);
	DEC_CONST(NUMEVENTS);

	DEC_CONST(HAT_CENTERED);
	DEC_CONST(HAT_UP);
	DEC_CONST(HAT_RIGHTUP);
	DEC_CONST(HAT_RIGHT);
	DEC_CONST(HAT_RIGHTDOWN);
	DEC_CONST(HAT_DOWN);
	DEC_CONST(HAT_LEFTDOWN);
	DEC_CONST(HAT_LEFT);
	DEC_CONST(HAT_LEFTUP);

	DEC_CONST(ACTIVEEVENTMASK);
	DEC_CONST(KEYDOWNMASK);
	DEC_CONST(KEYUPMASK);
	DEC_CONST(MOUSEMOTIONMASK);
	DEC_CONST(MOUSEBUTTONDOWNMASK);
	DEC_CONST(MOUSEBUTTONUPMASK);
	DEC_CONST(MOUSEEVENTMASK);
	DEC_CONST(JOYAXISMOTIONMASK);
	DEC_CONST(JOYBALLMOTIONMASK);
	DEC_CONST(JOYHATMOTIONMASK);
	DEC_CONST(JOYBUTTONDOWNMASK);
	DEC_CONST(JOYBUTTONUPMASK);
	DEC_CONST(JOYEVENTMASK);
	DEC_CONST(QUITMASK);
	DEC_CONST(ALLEVENTS);

	DEC_CONST(IGNORE);
	DEC_CONST(ENABLE);
	DEC_CONST(QUERY);

	DEC_CONST(DEFAULT_REPEAT_DELAY);
	DEC_CONST(DEFAULT_REPEAT_INTERVAL);

	DEC_CONST(APPMOUSEFOCUS);
	DEC_CONST(APPINPUTFOCUS);
	DEC_CONST(APPACTIVE);

	DEC_CONSTK(K_UNKNOWN);
	DEC_CONSTK(K_FIRST);
	DEC_CONSTK(K_BACKSPACE);
	DEC_CONSTK(K_TAB);
	DEC_CONSTK(K_CLEAR);
	DEC_CONSTK(K_RETURN);
	DEC_CONSTK(K_PAUSE);
	DEC_CONSTK(K_ESCAPE);
	DEC_CONSTK(K_SPACE);
	DEC_CONSTK(K_EXCLAIM);
	DEC_CONSTK(K_QUOTEDBL);
	DEC_CONSTK(K_HASH);
	DEC_CONSTK(K_DOLLAR);
	DEC_CONSTK(K_AMPERSAND);
	DEC_CONSTK(K_QUOTE);
	DEC_CONSTK(K_LEFTPAREN);
	DEC_CONSTK(K_RIGHTPAREN);
	DEC_CONSTK(K_ASTERISK);
	DEC_CONSTK(K_PLUS);
	DEC_CONSTK(K_COMMA);
	DEC_CONSTK(K_MINUS);
	DEC_CONSTK(K_PERIOD);
	DEC_CONSTK(K_SLASH);
	DEC_CONSTK(K_0);
	DEC_CONSTK(K_1);
	DEC_CONSTK(K_2);
	DEC_CONSTK(K_3);
	DEC_CONSTK(K_4);
	DEC_CONSTK(K_5);
	DEC_CONSTK(K_6);
	DEC_CONSTK(K_7);
	DEC_CONSTK(K_8);
	DEC_CONSTK(K_9);
	DEC_CONSTK(K_COLON);
	DEC_CONSTK(K_SEMICOLON);
	DEC_CONSTK(K_LESS);
	DEC_CONSTK(K_EQUALS);
	DEC_CONSTK(K_GREATER);
	DEC_CONSTK(K_QUESTION);
	DEC_CONSTK(K_AT);
	DEC_CONSTK(K_LEFTBRACKET);
	DEC_CONSTK(K_BACKSLASH);
	DEC_CONSTK(K_RIGHTBRACKET);
	DEC_CONSTK(K_CARET);
	DEC_CONSTK(K_UNDERSCORE);
	DEC_CONSTK(K_BACKQUOTE);
	DEC_CONSTK(K_a);
	DEC_CONSTK(K_b);
	DEC_CONSTK(K_c);
	DEC_CONSTK(K_d);
	DEC_CONSTK(K_e);
	DEC_CONSTK(K_f);
	DEC_CONSTK(K_g);
	DEC_CONSTK(K_h);
	DEC_CONSTK(K_i);
	DEC_CONSTK(K_j);
	DEC_CONSTK(K_k);
	DEC_CONSTK(K_l);
	DEC_CONSTK(K_m);
	DEC_CONSTK(K_n);
	DEC_CONSTK(K_o);
	DEC_CONSTK(K_p);
	DEC_CONSTK(K_q);
	DEC_CONSTK(K_r);
	DEC_CONSTK(K_s);
	DEC_CONSTK(K_t);
	DEC_CONSTK(K_u);
	DEC_CONSTK(K_v);
	DEC_CONSTK(K_w);
	DEC_CONSTK(K_x);
	DEC_CONSTK(K_y);
	DEC_CONSTK(K_z);
	DEC_CONSTK(K_DELETE);

	DEC_CONSTK(K_KP0);
	DEC_CONSTK(K_KP1);
	DEC_CONSTK(K_KP2);
	DEC_CONSTK(K_KP3);
	DEC_CONSTK(K_KP4);
	DEC_CONSTK(K_KP5);
	DEC_CONSTK(K_KP6);
	DEC_CONSTK(K_KP7);
	DEC_CONSTK(K_KP8);
	DEC_CONSTK(K_KP9);
	DEC_CONSTK(K_KP_PERIOD);
	DEC_CONSTK(K_KP_DIVIDE);
	DEC_CONSTK(K_KP_MULTIPLY);
	DEC_CONSTK(K_KP_MINUS);
	DEC_CONSTK(K_KP_PLUS);
	DEC_CONSTK(K_KP_ENTER);
	DEC_CONSTK(K_KP_EQUALS);
	DEC_CONSTK(K_UP);
	DEC_CONSTK(K_DOWN);
	DEC_CONSTK(K_RIGHT);
	DEC_CONSTK(K_LEFT);
	DEC_CONSTK(K_INSERT);
	DEC_CONSTK(K_HOME);
	DEC_CONSTK(K_END);
	DEC_CONSTK(K_PAGEUP);
	DEC_CONSTK(K_PAGEDOWN);
	DEC_CONSTK(K_F1);
	DEC_CONSTK(K_F2);
	DEC_CONSTK(K_F3);
	DEC_CONSTK(K_F4);
	DEC_CONSTK(K_F5);
	DEC_CONSTK(K_F6);
	DEC_CONSTK(K_F7);
	DEC_CONSTK(K_F8);
	DEC_CONSTK(K_F9);
	DEC_CONSTK(K_F10);
	DEC_CONSTK(K_F11);
	DEC_CONSTK(K_F12);
	DEC_CONSTK(K_F13);
	DEC_CONSTK(K_F14);
	DEC_CONSTK(K_F15);

	DEC_CONSTK(K_NUMLOCK);
	DEC_CONSTK(K_CAPSLOCK);
	DEC_CONSTK(K_SCROLLOCK);
	DEC_CONSTK(K_RSHIFT);
	DEC_CONSTK(K_LSHIFT);
	DEC_CONSTK(K_RCTRL);
	DEC_CONSTK(K_LCTRL);
	DEC_CONSTK(K_RALT);
	DEC_CONSTK(K_LALT);
	DEC_CONSTK(K_RMETA);
	DEC_CONSTK(K_LMETA);
	DEC_CONSTK(K_LSUPER);
	DEC_CONSTK(K_RSUPER);
	DEC_CONSTK(K_MODE);

	DEC_CONSTK(K_HELP);
	DEC_CONSTK(K_PRINT);
	DEC_CONSTK(K_SYSREQ);
	DEC_CONSTK(K_BREAK);
	DEC_CONSTK(K_MENU);
	DEC_CONSTK(K_POWER);
	DEC_CONSTK(K_EURO);
	DEC_CONSTK(K_LAST);

	DEC_CONSTN(KMOD_NONE);
	DEC_CONSTN(KMOD_LSHIFT);
	DEC_CONSTN(KMOD_RSHIFT);
	DEC_CONSTN(KMOD_LCTRL);
	DEC_CONSTN(KMOD_RCTRL);
	DEC_CONSTN(KMOD_LALT);
	DEC_CONSTN(KMOD_RALT);
	DEC_CONSTN(KMOD_LMETA);
	DEC_CONSTN(KMOD_RMETA);
	DEC_CONSTN(KMOD_NUM);
	DEC_CONSTN(KMOD_CAPS);
	DEC_CONSTN(KMOD_MODE);

	DEC_CONSTN(KMOD_CTRL);
	DEC_CONSTN(KMOD_SHIFT);
	DEC_CONSTN(KMOD_ALT);
	DEC_CONSTN(KMOD_META);

	DEC_CONST(PRESSED);
	DEC_CONST(RELEASED);


	DEC_CONSTN(IMAGE_BMP);
	DEC_CONSTN(IMAGE_PPM);
	DEC_CONSTN(IMAGE_PCX);
	DEC_CONSTN(IMAGE_GIF);
	DEC_CONSTN(IMAGE_JPEG);
	DEC_CONSTN(IMAGE_TIFF);
	DEC_CONSTN(IMAGE_PNG);

	DEC_CONSTN(MIX_CHANNELS);
	DEC_CONSTN(MIX_MAX_VOLUME);
	DEC_CONSTN(MIX_NO_FADING);
	DEC_CONSTN(MIX_FADING_OUT);
	DEC_CONSTN(MIX_FADING_IN);


	DEC_CONSTN(TTF_STYLE_NORMAL);
	DEC_CONSTN(TTF_STYLE_BOLD);
	DEC_CONSTN(TTF_STYLE_ITALIC);
	DEC_CONSTN(TTF_STYLE_UNDERLINE);
}

static PyObject* sdl_init(PyObject* self,PyObject* args)
{
	int status;
	Uint32 flags;

	if(!PyArg_ParseTuple(args, "i", &flags))
		return NULL;

	status = SDL_Init(flags);

	/* If we've initialized the subsystem asked for, then set the globals
	 * used to indicate that these systems are initialized/uninitialized.
	 * This is currently used for object wrapper destructors, and to restrict
	 * usage of objects, once its SDL subsystem has been shut down.
	*/

	if(!status)
	{
		sdl_is_initialized = 1;
		
		if(flags & SDL_INIT_VIDEO)
		{
			video_is_initialized = 1;
			TTF_Init();
		}
		if(flags & SDL_INIT_CDROM)
			cdrom_is_initialized = 1;
		if(flags & SDL_INIT_JOYSTICK)
			joy_is_initialized = 1;
		if(flags & SDL_INIT_AUDIO)
			audio_is_initialized = 1;
	}

	return PyInt_FromLong(status);
}

static PyObject* sdl_init_subsystem(PyObject* self, PyObject* args)
{
	int status;
	Uint32 flags;

	if(!PyArg_ParseTuple(args, "i", &flags))
		return NULL;

	status = SDL_InitSubSystem(flags);
	if(!status)
	{
		sdl_is_initialized = 1;
		if(flags & SDL_INIT_VIDEO)
		{
			video_is_initialized = 1;
			TTF_Init();
		}
		if(flags & SDL_INIT_CDROM)
			cdrom_is_initialized = 1;
		if(flags & SDL_INIT_JOYSTICK)
			joy_is_initialized = 1;
		if(flags & SDL_INIT_AUDIO)
			audio_is_initialized = 1;
	}
	return PyInt_FromLong(status);
}

static PyObject* sdl_quit_subsystem(PyObject* self, PyObject* args)
{
	Uint32 flags;

	if(!PyArg_ParseTuple(args, "i", &flags))
		return NULL;

	SDL_INIT_CHECK

	SDL_QuitSubSystem(flags);

	/* Reset the globals, so destructors won't call into SDL_* */ 
	if(flags & SDL_INIT_VIDEO)
	{
		video_is_initialized = 0;
		TTF_Quit();
	}
	if(flags & SDL_INIT_CDROM)
		cdrom_is_initialized = 0;
	if(flags & SDL_INIT_JOYSTICK)
		joy_is_initialized = 0;
	if(flags & SDL_INIT_AUDIO)
		audio_is_initialized = 0;
				
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_quit(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	SDL_INIT_CHECK
	
	if(video_is_initialized)
		TTF_Quit();
			
	SDL_Quit();

	sdl_is_initialized = 0;
	video_is_initialized = 0;
	cdrom_is_initialized = 0;
	joy_is_initialized = 0;
	audio_is_initialized = 0;
	
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_get_app_state(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	SDL_INIT_CHECK

	return PyInt_FromLong(SDL_GetAppState());
}

static PyObject* sdl_video_init(PyObject* self, PyObject* args)
{
	Uint32 flags;
	char* driver_name;
	int status;
	
	if(!PyArg_ParseTuple(args, "si", &driver_name, &flags))
		return NULL;

	SDL_INIT_CHECK	
	
	status = SDL_VideoInit(driver_name,flags);
	if(status)
	{
		video_is_initialized = 1;
		sdl_is_initialized = 1;
		TTF_Init();
	}

	return PyInt_FromLong(status);
}

static PyObject* sdl_video_quit(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	VIDEO_INIT_CHECK

	TTF_Quit();
	SDL_VideoQuit();

	video_is_initialized = 0;
	
	Py_INCREF(Py_None);
	return Py_None;

}

static PyObject* sdl_video_driver_name(PyObject* self, PyObject* args)
{
	char buf[256];
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	VIDEO_INIT_CHECK

	if(!SDL_VideoDriverName(buf, sizeof(buf)))
	{
		Py_INCREF(Py_None);
		return Py_None;
	}
	return PyString_FromString(buf);
}

static PyObject* sdl_video_get_surface(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	VIDEO_INIT_CHECK

	return sdl_surface_NEW(SDL_GetVideoSurface());
}

static PyObject* sdl_video_set_mode(PyObject* self, PyObject* args)
{
	int width, height, depth;
	Uint32 flags;
	PyObject* surface;
	
	if(!PyArg_ParseTuple(args, "iiii", &width, &height, &depth, &flags))
		return NULL;

	surface = sdl_surface_NEW(SDL_SetVideoMode(width, height, depth, flags));
	if(surface)
	{
		video_is_initialized = 1;
		sdl_is_initialized = 1;
		TTF_Init();
	}

	return surface;
}

static PyObject* sdl_video_mode_ok(PyObject* self, PyObject* args)
{
	int width, height, depth;
	Uint32 flags;

	VIDEO_INIT_CHECK

	if(!PyArg_ParseTuple(args, "iiii", &width, &height, &depth, &flags))
		return NULL;

	return PyInt_FromLong(SDL_VideoModeOK(width, height, depth, flags));
}

static PyObject* sdl_video_list_modes(PyObject* self, PyObject* args)
{
	SDL_PixelFormat format;
	SDL_Rect** rects_ref;
	Uint32 flags;
	PyObject* list_ref;
	
	if(!PyArg_ParseTuple(args, "bi", &format.BitsPerPixel, &flags))
		return NULL;

	VIDEO_INIT_CHECK

	rects_ref = SDL_ListModes(&format, flags);
	if(rects_ref == (SDL_Rect**)-1)
		return PyInt_FromLong(-1);

	if(rects_ref == NULL)
		return PyInt_FromLong(0);

	/* We don't yet know how many elements there are, so let's just be memory
	 * conservative and start at 0. This wastes cpu though, but it's unlikely
	 * to matter here.
	*/
	
	list_ref = PyList_New(0);
	if(!list_ref)
		return NULL;

	while(rects_ref != NULL)
	{
		PyObject* tuple_ref;
		PyObject* rect_elem;

		tuple_ref = PyTuple_New(4);
		if(!tuple_ref)
		{
			Py_DECREF(list_ref);
			return NULL;
		}

		/* x component */
		rect_elem = PyInt_FromLong((*rects_ref)->x);
		PyTuple_SET_ITEM(tuple_ref, 0, rect_elem);

		/* y component */		
		rect_elem = PyInt_FromLong((*rects_ref)->y);
		PyTuple_SET_ITEM(tuple_ref, 1, rect_elem);

		/* width component */		
		rect_elem = PyInt_FromLong((*rects_ref)->w);
		PyTuple_SET_ITEM(tuple_ref, 2, rect_elem);

		/* height component */		
		rect_elem = PyInt_FromLong((*rects_ref)->h);
		PyTuple_SET_ITEM(tuple_ref, 3, rect_elem);

		/* Append the new tuple, and decrement its reference count, since
		 * PyList_Append increments it
		*/
		PyList_Append(list_ref, tuple_ref);
		Py_DECREF(tuple_ref);

		(*rects_ref)++;
	}
	return list_ref;
}

static PyObject* sdl_video_info(PyObject* self, PyObject* args)
{
	const SDL_VideoInfo* video_info;
	int flag;
	
	if(!PyArg_ParseTuple(args, "i", &flag))
		return NULL;

	VIDEO_INIT_CHECK

	video_info = SDL_GetVideoInfo();
	if(!video_info)
	{
		PyErr_SetString(PyExc_RuntimeError, "video subsystem not initialized.");
		return NULL;
	}
	
	switch(flag)
	{
		case INFO_HW_A:
			return PyInt_FromLong(video_info->hw_available);
		case INFO_WM_A:
			return PyInt_FromLong(video_info->wm_available);
		case INFO_BLT_HW:
			return PyInt_FromLong(video_info->blit_hw);
		case INFO_BLT_HW_CC:
			return PyInt_FromLong(video_info->blit_hw_CC);
		case INFO_BLT_HW_A:
			return PyInt_FromLong(video_info->blit_hw_A);
		case INFO_BLT_SW:
			return PyInt_FromLong(video_info->blit_sw);
		case INFO_BLT_SW_CC:
			return PyInt_FromLong(video_info->blit_sw_CC);
		case INFO_BLT_SW_A:
			return PyInt_FromLong(video_info->blit_sw_A);
		case INFO_BLT_FILL:
			return PyInt_FromLong(video_info->blit_fill);
		case INFO_MEM:
			return PyInt_FromLong(video_info->video_mem);
	}
	/* This shouldn't happen. */
	return PyInt_FromLong(-1);

}

static PyObject* sdl_video_set_gl(PyObject* self, PyObject* args)
{
	int attr, value;
	
	if(!PyArg_ParseTuple(args, "ii", &attr, &value))
		return NULL;

	VIDEO_INIT_CHECK

	return PyInt_FromLong(SDL_GL_SetAttribute(attr, value));
}

static PyObject* sdl_video_get_gl(PyObject* self, PyObject* args)
{
	int attr, value;

	if(!PyArg_ParseTuple(args, "i", &attr))
		return NULL;

	VIDEO_INIT_CHECK

	if(SDL_GL_GetAttribute(attr, &value) == -1)
	{
		PyErr_SetString(PyExc_RuntimeError, "Unable to get attribute.");
		return NULL;
	}

	return PyInt_FromLong(value);
}

static PyObject* sdl_video_swap_gl(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	VIDEO_INIT_CHECK

	SDL_GL_SwapBuffers();

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_wm_grab_input(PyObject* self, PyObject* args)
{
	int mode;
	if(!PyArg_ParseTuple(args, "i", &mode))
		return NULL;

	VIDEO_INIT_CHECK

	return PyInt_FromLong(SDL_WM_GrabInput(mode));
}

static PyObject* sdl_wm_toggle_fullscreen(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref;
	
	if(!PyArg_ParseTuple(args,"O!", &Surface_Type, &surface_ref))
		return NULL;

	VIDEO_INIT_CHECK
	
	return PyInt_FromLong(SDL_WM_ToggleFullScreen(surface_ref->surf));
}

static PyObject* sdl_wm_iconify(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	VIDEO_INIT_CHECK

	return PyInt_FromLong(SDL_WM_IconifyWindow());
}

static PyObject* sdl_wm_set_icon(PyObject* self, PyObject* args)
{
	Surface_Object* icon;
	if(!PyArg_ParseTuple(args,"O!", &Surface_Type, &icon))
		return NULL;

	VIDEO_INIT_CHECK

	SDL_WM_SetIcon(icon->surf, NULL);

	Py_INCREF(Py_None);
	return Py_None;
}


static PyObject* sdl_wm_get_caption(PyObject* self, PyObject* args)
{
	char* title;
	char* icon_title;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	VIDEO_INIT_CHECK

	SDL_WM_GetCaption(&title, &icon_title);

	return Py_BuildValue("(ss)", title, icon_title);
}

static PyObject* sdl_wm_set_caption(PyObject* self, PyObject* args)
{
	char* title;
	char* icon_title;

	if(!PyArg_ParseTuple(args, "ss", &title, &icon_title))
		return NULL;

	VIDEO_INIT_CHECK

	SDL_WM_SetCaption(title, icon_title);

	Py_INCREF(Py_None);
	return Py_None;	
}

static PyObject* sdl_font_load(PyObject* self, PyObject* args)
{
	char* filename;
	int fontsize;

	if(!PyArg_ParseTuple(args, "si", &filename, &fontsize))
		return NULL;

	VIDEO_INIT_CHECK

	return sdl_font_NEW(TTF_OpenFont(filename, fontsize));
}

static PyObject* sdl_image_load(PyObject* self, PyObject* args)
{
	PyObject* arg_ref;
	PyObject* surface_ref;
	RW_Object* ops_ref;

	if(!PyArg_ParseTuple(args, "O", &arg_ref))
		return NULL;

	VIDEO_INIT_CHECK

	ops_ref = rw_NEW(arg_ref, "rb");
	if(!ops_ref)
		return NULL;

	surface_ref = sdl_surface_NEW(IMG_Load_RW((SDL_RWops*)ops_ref, 0));
	rw_DEL(ops_ref);

	return surface_ref;
}

static PyObject* sdl_image_is(PyObject* self, PyObject* args)
{
	PyObject* arg_ref;
	RW_Object* ops_ref;
	int type, status;
	
	if(!PyArg_ParseTuple(args, "Oi", &arg_ref, &type))
		return NULL;

	VIDEO_INIT_CHECK

	ops_ref = rw_NEW(arg_ref, "rb");
	if(!ops_ref)
		return NULL;

	switch(type)
	{
		case IMAGE_BMP:
			status = IMG_isBMP((SDL_RWops*)ops_ref);
			break;
		case IMAGE_PPM:
			status = IMG_isPPM((SDL_RWops*)ops_ref);
			break;
		case IMAGE_PCX:
			status = IMG_isPCX((SDL_RWops*)ops_ref);
			break;
		case IMAGE_GIF:
			status = IMG_isGIF((SDL_RWops*)ops_ref);
			break;
		case IMAGE_JPEG:
			status = IMG_isJPG((SDL_RWops*)ops_ref);
			break;
		case IMAGE_TIFF:
			status = IMG_isTIF((SDL_RWops*)ops_ref);
			break;
		case IMAGE_PNG:
			status = IMG_isPNG((SDL_RWops*)ops_ref);
			break;
		default:
			/* If it's an invalid image type, it'll always be false */
			status = 0;
	}

	rw_DEL(ops_ref);
	return PyInt_FromLong(status);
}

static PyObject* sdl_image_load_type(PyObject* self, PyObject* args)
{
	PyObject* arg_ref;
	RW_Object* ops_ref;
	int type;
	SDL_Surface* s_surface_ref;

	if(!PyArg_ParseTuple(args, "Oi", &arg_ref, &type))
		return NULL;

	VIDEO_INIT_CHECK

	ops_ref = rw_NEW(arg_ref, "rb");
	if(!ops_ref)
		return NULL;

	switch(type)
	{
		case IMAGE_BMP:
			s_surface_ref = IMG_LoadBMP_RW((SDL_RWops*)ops_ref);
			break;
		case IMAGE_PPM:
			s_surface_ref = IMG_LoadPPM_RW((SDL_RWops*)ops_ref);
			break;
		case IMAGE_PCX:
			s_surface_ref = IMG_LoadPCX_RW((SDL_RWops*)ops_ref);
			break;
		case IMAGE_GIF:
			s_surface_ref = IMG_LoadGIF_RW((SDL_RWops*)ops_ref);
			break;
		case IMAGE_JPEG:
			/* If this isn't a JPEG, calling this will abort the program.
			 * This seems to be a bit of a bug, to me, in SDL_image */
			s_surface_ref = IMG_LoadJPG_RW((SDL_RWops*)ops_ref);
			break;
		case IMAGE_TIFF:
			s_surface_ref = IMG_LoadTIF_RW((SDL_RWops*)ops_ref);
			break;
		case IMAGE_PNG:
			s_surface_ref = IMG_LoadPNG_RW((SDL_RWops*)ops_ref);
			break;
		default:
			/* sdl_surface_NEW throws an exception if its argument is NULL */
			s_surface_ref = NULL;
	}														 

	rw_DEL(ops_ref);
	return sdl_surface_NEW(s_surface_ref);
}

static PyObject* sdl_image_invert_alpha(PyObject* self, PyObject* args)
{
	int on;

	if(!PyArg_ParseTuple(args, "i", &on))
		return NULL;

	VIDEO_INIT_CHECK

	return PyInt_FromLong(IMG_InvertAlpha(on));
}

static PyObject* sdl_get_error(PyObject* self, PyObject* args)
{
	char* err_msg;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	err_msg = SDL_GetError();

	return PyString_FromString(err_msg);
}

static PyObject* sdl_get_ticks(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	SDL_INIT_CHECK

	return PyInt_FromLong(SDL_GetTicks());
}

static PyObject* sdl_delay(PyObject* self, PyObject* args)
{
	int delay;

	if(!PyArg_ParseTuple(args, "i", &delay))
		return NULL;

	SDL_INIT_CHECK

	SDL_Delay(delay);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_cursor_show(PyObject* self, PyObject* args)
{
	int toggle;

	if(!PyArg_ParseTuple(args, "i", &toggle))
		return NULL;

	VIDEO_INIT_CHECK

	return PyInt_FromLong(SDL_ShowCursor(toggle));
}

static PyObject* sdl_mouse_warp(PyObject* self, PyObject* args)
{
	Uint16 x, y;

	if(!PyArg_ParseTuple(args, "hh", &x, &y))
		return NULL;

	VIDEO_INIT_CHECK

	SDL_WarpMouse(x, y);

	Py_INCREF(Py_None);
	return Py_None;
}

/* Surface object related routines */

static PyObject* sdl_surface_NEW(SDL_Surface* surf)
{
	Surface_Object* surface;

	if(!surf)
	{
		PyErr_SetString(PyExc_RuntimeError, "unable to allocate SDL surface");
		return NULL;
	}
		

	surface = PyObject_NEW(Surface_Object, &Surface_Type);
	if(!surface) return NULL;
	
	surface->surf = surf;

	return (PyObject*)surface;
}

static PyObject* sdl_surface_new(PyObject* self,PyObject* args)
{
	Uint32 flags;
	int width, height, depth;
	Uint32 Rmask, Gmask, Bmask, Amask;
	SDL_Surface* surface_ref;
	
	if(!PyArg_ParseTuple(args, "iiii(iiii)",
		&flags, &width, &height, &depth,
		&Rmask, &Gmask, &Bmask, &Amask))
		return NULL;

	VIDEO_INIT_CHECK

	surface_ref = SDL_CreateRGBSurface(flags, width, height, depth,
		Rmask, Gmask, Bmask, Amask);

	return sdl_surface_NEW(surface_ref);
}

static void sdl_surface_dealloc(PyObject* self)
{
	Surface_Object* surface_ref = (Surface_Object*)self;

	if(video_is_initialized && sdl_is_initialized)
		SDL_FreeSurface(surface_ref->surf);
	PyMem_DEL(self);
}

static PyObject* sdl_surface_getattr(PyObject* self, char* attrname)
{
	if(video_is_initialized && sdl_is_initialized)
		return Py_FindMethod(sdl_surface__builtins__, self, attrname);

	PyErr_SetString(PyExc_NameError, attrname);
	return NULL;
}

static PyObject* sdl_surface_seq_get(PyObject* self, int index)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_Surface* s_surface_ref = surface_ref->surf;
	SDL_PixelFormat* format_ref;
	Uint8* pix_buf;
	PyObject* rgb_list;
	PyObject* list_elem;
	int x, w;
	Uint16 pitch;
	
	if(!sdl_is_initialized || ! video_is_initialized)
	{
		PyErr_SetString(PyExc_RuntimeError, "SDL has shut down.");
		return NULL;
	}
	
	if(index >= s_surface_ref->h || index < 0)
	{
		PyErr_SetString(PyExc_IndexError, "buffer index out of range");
		return NULL;
	}
	
	format_ref = s_surface_ref->format;
	pix_buf = s_surface_ref->pixels;
	pitch = s_surface_ref->pitch;
	w = s_surface_ref->w;
	
	rgb_list = PyList_New(w);
	if(!rgb_list)
		return NULL;

	/* 
	 * The loops are inside of each case, instead of having one loop with
	 * different behavior based on the case. The reason for this is simple;
	 * the less done inside of the loops, the faster they are.
	 * There's really no reason to recheck, each iteration, if this is a
	 * 8, 16, 24, or 32 bit surface
	*/
	switch(format_ref->BytesPerPixel)
	{
		case 1:
		{
			Uint8 ind;
			
			for(x = 0;x < w;x++)
			{
				/* return the color as its index */
				ind = *((Uint8*)pix_buf + index * pitch + x);
				list_elem = PyInt_FromLong(ind);
				PyList_SET_ITEM(rgb_list, x, list_elem);
			}
			return rgb_list;
		}
		case 2:
		{
			Uint16 col;

			for(x = 0;x < w;x++)
			{
				col = *((Uint16*)(pix_buf + index * pitch) + x);
				list_elem = PyInt_FromLong(col);
				PyList_SET_ITEM(rgb_list, x, list_elem);
			}
			return rgb_list;
		}
		case 3:
		{
			Uint32 col;
			Uint8* byte_buf;
			for(x = 0;x < w;x++)
			{
				byte_buf = ((Uint8*)pix_buf + index * pitch + x * 3);
				col = 
					*(byte_buf + (format_ref->Rshift >> 3)) << format_ref->Rshift |
					*(byte_buf + (format_ref->Gshift >> 3)) << format_ref->Gshift |
					*(byte_buf + (format_ref->Bshift >> 3)) << format_ref->Bshift;
				list_elem = PyInt_FromLong(col);
				PyList_SET_ITEM(rgb_list, x, list_elem);
			}
			return rgb_list;
		}
		case 4:
		{
			Uint32 col;
			for(x = 0;x< w;x++)
			{
				col = *((Uint32*)(pix_buf + index * pitch) + x);
				list_elem = PyInt_FromLong(col);
				PyList_SET_ITEM(rgb_list, x, list_elem);
			}
			return rgb_list;
		}
	}
	PyErr_SetString(PyExc_RuntimeError, "Unable to determine color depth.");
	return NULL;
}

static PyObject* sdl_surface_seq_get_slice(PyObject* self, int start, int end)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_Surface* s_surface_ref = surface_ref->surf;
	SDL_PixelFormat* format_ref;
	Uint8* pix_buf;
	int w, x;
	int i;
	PyObject* y_list;
	PyObject* x_list;
	PyObject* list_elem;
	Uint16 pitch;
	
	if(!sdl_is_initialized || !video_is_initialized)
	{
		PyErr_SetString(PyExc_RuntimeError, "SDL has shut down.");
		return NULL;
	}

	if(start < 0)
	{
		PyErr_SetString(PyExc_IndexError, "Index out of range.");
		return NULL;
	}     

	format_ref = s_surface_ref->format;
	pix_buf = s_surface_ref->pixels;

	pitch = s_surface_ref->pitch;

	i = min(start,end);
	end = max(start,end);
	start = i;

	w = s_surface_ref->w;
	end = min(end, s_surface_ref->h);

	y_list = PyList_New(end - start);
	if(!y_list)
		return NULL;

	switch(format_ref->BytesPerPixel)
	{
		case 1:
		{
			Uint8 ind;

			for(i = 0; start < end; start++, i++)
			{
				x_list = PyList_New(w);
				if(!x_list)
				{
					Py_DECREF(y_list);
					return NULL;
				}
				
				for(x = 0;x < w;x++)
				{
					ind = *((Uint8*)pix_buf + start * pitch + x);
					list_elem = PyInt_FromLong(ind);
					PyList_SET_ITEM(x_list, x, list_elem);    
				}
				PyList_SET_ITEM(y_list, i, x_list);
			}
			return y_list;
		}
		case 2:
		{
			Uint16 col;
			for(i = 0; start < end; start++, i++)
			{
				x_list = PyList_New(w);
				if(!x_list)
				{
					Py_DECREF(y_list);
					return NULL;
				}

				for(x = 0;x < w;x++)
				{
					col = *((Uint16*)(pix_buf + start * pitch) + x);
					list_elem = PyInt_FromLong(col);
					PyList_SET_ITEM(x_list, x, list_elem);
				}

				PyList_SET_ITEM(y_list, i, x_list);
			}
			return y_list; 
		}
		case 3:
		{
			Uint32 col;
			Uint8* byte_buf;
			for(i = 0; start < end; start++, i++)
			{
				x_list = PyList_New(w);
				if(!x_list)
				{
					Py_DECREF(y_list);
					return NULL;
				}
				for(x = 0;x < w;x++)
				{
					byte_buf = ((Uint8*)pix_buf + start * pitch + x * 3);
					col =
						*(byte_buf + (format_ref->Rshift >> 3)) 
							<< format_ref->Rshift |
						*(byte_buf + (format_ref->Gshift >> 3)) 
							<< format_ref->Gshift |
						*(byte_buf + (format_ref->Bshift >> 3)) 
							<< format_ref->Bshift;

					list_elem = PyInt_FromLong(col);
					PyList_SET_ITEM(x_list, x, list_elem);
				}
				PyList_SET_ITEM(y_list, i, x_list);
			}
			return y_list;
		}
		case 4:
		{
			Uint32 col;
			for(i = 0; start < end; start++, i++)
			{
				x_list = PyList_New(w);
				if(!x_list)
				{
					Py_DECREF(y_list);
					return NULL;
				}
				for(x = 0;x< w;x++)
				{
					col = *((Uint32*)(pix_buf + start * pitch) + x);
					list_elem = PyInt_FromLong(col);
					
					PyList_SET_ITEM(x_list, x, list_elem);
				}
				PyList_SET_ITEM(y_list, i, x_list);
			}
			return y_list;
		}
	}

	PyErr_SetString(PyExc_RuntimeError, "Unable to determine color depth.");
	return NULL; 
}

static int sdl_surface_seq_set(PyObject* self, int index, PyObject* value)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_Surface* s_surface_ref = surface_ref->surf;
	SDL_PixelFormat* format_ref;
	Uint8* pix_buf;
	int x, w;
	Uint32 col;
	Uint16 pitch;
			
	if(!sdl_is_initialized || !video_is_initialized)
	{
		PyErr_SetString(PyExc_RuntimeError, "SDL has shut down.");
		return -1;
	}

	if(!PyList_Check(value))
	{
		PyErr_SetString(PyExc_TypeError, "takes a list of colors");
		return -1;
	}

	if(index >= s_surface_ref->h)
	{
		PyErr_SetString(PyExc_IndexError, "buffer index out of range");
		return -1;
	}

	format_ref  = s_surface_ref->format;
	pix_buf = s_surface_ref->pixels;
	pitch = s_surface_ref->pitch;
	w = min(s_surface_ref->w, PyList_GET_SIZE(value));

	switch(format_ref->BytesPerPixel)
	{
		case 1:
		{
			for(x = 0;x < w;x++)
			{
				col = PyInt_AS_LONG(PyList_GET_ITEM(value, x));
				*(((Uint8*)pix_buf) + index * pitch + x) = (Uint8)col;
			}				
			return 0;
		}

		case 2:
		{
			for(x = 0;x < w;x++)
			{
				col = PyInt_AS_LONG(PyList_GET_ITEM(value, x));
				*((Uint16*)(pix_buf + index * pitch) + x) = (Uint16)col;
			}
			return 0;
		}

		case 3:
		{
			Uint8* byte_buf;
			Uint8 r, g, b;
			
			for(x = 0;x < w;x++)
			{
				byte_buf = ((Uint8*)pix_buf + index * pitch + x * 3);
				col = PyInt_AS_LONG(PyList_GET_ITEM(value, x));

				r = (col & format_ref->Rmask) >> format_ref->Rshift;
				g = (col & format_ref->Gmask) >> format_ref->Gshift;
				b = (col & format_ref->Bmask) >> format_ref->Bshift;
			
				*(byte_buf + (format_ref->Rshift >> 3)) = r;
				*(byte_buf + (format_ref->Gshift >> 3)) = g;
				*(byte_buf + (format_ref->Bshift >> 3)) = b;
			}
			return 0;
		}

		case 4:
		{
			for(x = 0;x < w;x++)
			{
				col = PyInt_AS_LONG(PyList_GET_ITEM(value, x));
				*((Uint32*)(pix_buf + index * pitch) + x) = col;
			}
			return 0;
		}
	}

	PyErr_SetString(PyExc_RuntimeError, "Unable to determine color depth.");
	return -1;
}

static int sdl_surface_seq_set_slice(PyObject* self, int start, int end,
	PyObject* value)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_Surface* s_surface_ref = surface_ref->surf;
	SDL_PixelFormat* format_ref;
	Uint8* pix_buf;
	int w, x;
	int i;
	PyObject* x_list;
	Uint16 pitch;

	if(!sdl_is_initialized || !video_is_initialized)
	{
		PyErr_SetString(PyExc_RuntimeError, "SDL has shut down.");
		return -1;
	}

	if(!PyList_Check(value))
	{
		PyErr_SetString(PyExc_TypeError, "takes a list of lists of colors");
		return -1;
	}

	if(start >= s_surface_ref->h)
	{
		PyErr_SetString(PyExc_IndexError, "buffer index out of range");
		return -1;
	}

	format_ref = s_surface_ref->format;
	pix_buf = s_surface_ref->pixels;
	pitch = s_surface_ref->pitch;

	i = min(start,end);
	end = max(start,end);
	start = i;
	
	end = min(end, s_surface_ref->h);
	end = min(end, start + PyList_GET_SIZE(value));

	switch(format_ref->BytesPerPixel)
	{
		case 1:
		{
			Uint8 col;
			for(i = 0;start < end; start++, i++)
			{
				x_list = PyList_GET_ITEM(value, i);
				if(!PyList_Check(x_list))
				{
					PyErr_SetString(PyExc_TypeError,
						"takes a list of lists of colors");
					return -1;
				}
				w = min(s_surface_ref->w, PyList_GET_SIZE(x_list));
				for(x = 0;x < w;x++)
				{
					col = PyInt_AS_LONG(PyList_GET_ITEM(x_list, x));
					*(((Uint8*)pix_buf) + start * pitch + x) = col;
				} 
			}
			return 0;
		}
		case 2:
		{
			Uint16 col;

			for(i = 0;start < end; start++, i++)
			{
				x_list = PyList_GET_ITEM(value, i);
				if(!PyList_Check(x_list))
				{
					PyErr_SetString(PyExc_TypeError,
						"takes a list of lists of colors");
					return -1;
				}
				w = min(s_surface_ref->w, PyList_GET_SIZE(x_list));
				for(x = 0;x < w;x++)
				{
					col = PyInt_AS_LONG(PyList_GET_ITEM(x_list, x));
					*((Uint16*)(pix_buf + start * pitch) + x) = col;
				}
			}
			return 0;
		}
		case 3:
		{
			Uint32 col;
			Uint8* byte_buf;
			Uint8 r, g, b;
			for(i = 0;start < end; start++, i++)
			{
				x_list = PyList_GET_ITEM(value, i);
				if(!x_list)
				{
					PyErr_SetString(PyExc_TypeError,
						"takes a list of lists of colors");
					return -1;
				}
				w = min(s_surface_ref->w, PyList_GET_SIZE(x_list));
				for(x = 0;x < w;x++)
				{
					byte_buf = ((Uint8*)pix_buf + start * pitch + x * 3);
					col = PyInt_AS_LONG(PyList_GET_ITEM(x_list, x));
					r = (col & format_ref->Rmask) >> format_ref->Rshift;
					g = (col & format_ref->Gmask) >> format_ref->Gshift;
					b = (col & format_ref->Bmask) >> format_ref->Bshift;

					*(byte_buf + (format_ref->Rshift >> 3)) = r;
					*(byte_buf + (format_ref->Gshift >> 3)) = g;
					*(byte_buf + (format_ref->Bshift >> 3)) = b;
				}
			}
			return 0;
		}
		case 4:
		{
			Uint32 col;

			for(i = 0;start < end; start++, i++)
			{
				x_list = PyList_GET_ITEM(value, i);
				if(!PyList_Check(x_list))
				{
					PyErr_SetString(PyExc_TypeError,
						"takes a list of lists of colors");
					return -1;
				}
				w = min(s_surface_ref->w, PyList_GET_SIZE(x_list));
            for(x = 0;x < w;x++)
				{
					col = PyInt_AS_LONG(PyList_GET_ITEM(x_list, x));
					*((Uint32*)(pix_buf + start * pitch) + x) = col; 
				}
			}
			return 0;
		}
	}

	PyErr_SetString(PyExc_RuntimeError, "Unable to determine color depth.");
	return -1; 
}

static int sdl_surface_seq_len(PyObject* self)
{
	Surface_Object* surface_ref = (Surface_Object*)self;

	if(!sdl_is_initialized || !video_is_initialized)
	{
		PyErr_SetString(PyExc_RuntimeError, "SDL has shut down.");
		return -1;
	}

	return surface_ref->surf->h;
}

static PyObject* sdl_surface_get_at(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_Surface* s_surface_ref = surface_ref->surf;
	SDL_PixelFormat* format_ref = s_surface_ref->format;
	Uint8* pix_buf = (Uint8*)s_surface_ref->pixels;
	int x, y;

	if(!PyArg_ParseTuple(args, "ii", &x, &y))
		return NULL;

	if(x < 0 || x >= s_surface_ref->w || y < 0 || y >= s_surface_ref->h)
	{
		PyErr_SetString(PyExc_IndexError, "buffer index out of range");
		return NULL;
	}
	switch(format_ref->BytesPerPixel)
	{
		case 1:
		{
			Uint8 col;
			col = *((Uint8*)pix_buf + y * s_surface_ref->pitch + x);
			return PyInt_FromLong(col);
		}
		case 2:
		{
			Uint16 col;
			col = *((Uint16*)(pix_buf + y * s_surface_ref->pitch) + x);
			return PyInt_FromLong(col); 
		}
		case 3:
		{
			Uint32 col;
			Uint8* byte_buf;
			
			byte_buf = ((Uint8*)(pix_buf + y * s_surface_ref->pitch) + x * 3);
			col =
				*(byte_buf + (format_ref->Rshift >> 3)) << format_ref->Rshift |
				*(byte_buf + (format_ref->Gshift >> 3)) << format_ref->Gshift |
				*(byte_buf + (format_ref->Bshift >> 3)) << format_ref->Bshift;
			return PyInt_FromLong(col);   
		}
		case 4:
		{
			Uint32 col = *((Uint32*)(pix_buf + y * s_surface_ref->pitch) + x);
			return PyInt_FromLong(col); 
		}
	}
	PyErr_SetString(PyExc_RuntimeError, "Unable to determine color depth.");
	return NULL;
}

static PyObject* sdl_surface_set_at(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_Surface* s_surface_ref = surface_ref->surf;
	SDL_PixelFormat* format_ref = s_surface_ref->format;
	Uint8* pix_buf = s_surface_ref->pixels;
	int x, y;
	Uint32 pixel;
	
	if(!PyArg_ParseTuple(args, "iii", &x, &y, &pixel))
		return NULL;

	if(x < 0 || x >= s_surface_ref->w || y < 0 || y >= s_surface_ref->h)
	{
		PyErr_SetString(PyExc_IndexError, "buffer index out of range");
		return NULL;
	}

	switch(format_ref->BytesPerPixel)
	{
		case 1:
		{
			*((Uint8*)pix_buf + y * s_surface_ref->pitch + x) = (Uint8)pixel;
			Py_INCREF(Py_None);
			return Py_None;
		}
		case 2:
		{
			*((Uint16*)(pix_buf + y * s_surface_ref->pitch) + x) = (Uint16)pixel;
			Py_INCREF(Py_None);
			return Py_None;
		}
		case 3:
		{
			Uint8* byte_buf = (Uint8*)(pix_buf + y * s_surface_ref->pitch) + x * 3;
			Uint8 r, g, b;

			r = (pixel & format_ref->Rmask) >> format_ref->Rshift;
			g = (pixel & format_ref->Gmask) >> format_ref->Gshift;
			b = (pixel & format_ref->Bmask) >> format_ref->Bshift;

			*(byte_buf + (format_ref->Rshift >> 3)) = r;
			*(byte_buf + (format_ref->Gshift >> 3)) = g;
			*(byte_buf + (format_ref->Bshift >> 3)) = b;	

			Py_INCREF(Py_None);
			return Py_None;
		}
		case 4:
		{
			*((Uint32*)(pix_buf + y * s_surface_ref->pitch) + x) = pixel;
			Py_INCREF(Py_None);
			return Py_None;
		}
	}

	PyErr_SetString(PyExc_RuntimeError, "Unable to determine color depth.");
	return NULL;
}


static PyObject* sdl_surface_get_height(PyObject* self,PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(surface_ref->surf->h);
}

static PyObject* sdl_surface_get_width(PyObject* self,PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(surface_ref->surf->w);
}

static PyObject* sdl_surface_get_pitch(PyObject* self,PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(surface_ref->surf->pitch);
}

static PyObject* sdl_surface_map_rgb(PyObject* self,PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	Uint8 r, g, b;

	if(!PyArg_ParseTuple(args, "(bbb)", &r, &g, &b))
		return NULL;

	return PyInt_FromLong(SDL_MapRGB(surface_ref->surf->format, r, g, b));

}

static PyObject* sdl_surface_get_rgb(PyObject* self,PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	Uint32 col;
	Uint8 r, g, b;
	
	if(!PyArg_ParseTuple(args, "i", &col))
		return NULL;

	SDL_GetRGB(col,surface_ref->surf->format, &r, &g, &b);	

	return Py_BuildValue("(bbb)", r, g, b);
}

static PyObject* sdl_surface_lock(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(SDL_LockSurface(surface_ref->surf));
}

static PyObject* sdl_surface_unlock(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	SDL_UnlockSurface(surface_ref->surf);

	Py_INCREF(Py_None);
	return Py_None;

}

static PyObject* sdl_surface_mustlock(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(SDL_MUSTLOCK(surface_ref->surf));
}

static PyObject* sdl_surface_get_clip(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_Surface* s_surface_ref = surface_ref->surf;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(iiii)",
		s_surface_ref->clip_minx, s_surface_ref->clip_miny,
		s_surface_ref->clip_maxx, s_surface_ref->clip_maxy);

}

static PyObject* sdl_surface_update_rect(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	Sint32 x, y;
	Uint32 w, h;

	if(!PyArg_ParseTuple(args, "(iiii)", &x, &y, &w, &h))
		return  NULL;

	SDL_UpdateRect(surface_ref->surf, x, y, w, h);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_surface_update_rects(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_Rect* rects;
	PyObject* rects_list;
	int numrects;
	int i;

	if(!PyArg_ParseTuple(args, "O!", &PyList_Type, &rects_list))
		return NULL;

	numrects = PyList_Size(rects_list);
	rects = Py_Malloc(numrects * sizeof(SDL_Rect));

	for(i = 0;i < numrects;i++)
	{
		SDL_Rect* rect_ref = &rects[i];
		PyObject* tuple_ref = PyList_GET_ITEM(rects_list,i);

		if(!PyArg_Parse(tuple_ref, "(hhhh);requires four element tuple",
			&rect_ref->x, &rect_ref->y,
			&rect_ref->w, &rect_ref->h))
		{
			Py_Free(rects);
			return NULL;
		}

	}
	SDL_UpdateRects(surface_ref->surf,numrects,rects);
	Py_Free(rects);
	
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_surface_get_masks(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;
								
	return Py_BuildValue("(iiii)",
		format_ref->Rmask, format_ref->Gmask,
		format_ref->Bmask, format_ref->Amask);
}

static PyObject* sdl_surface_get_shifts(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(bbbb)",
		format_ref->Rshift, format_ref->Gshift,
		format_ref->Bshift, format_ref->Ashift);
}

static PyObject* sdl_surface_get_losses(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(bbbb)",
		format_ref->Rloss, format_ref->Gloss,
		format_ref->Bloss, format_ref->Aloss);
}

static PyObject* sdl_surface_get_alpha(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(format_ref->alpha);
}

static PyObject* sdl_surface_get_colorkey(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(format_ref->colorkey);
}

static PyObject* sdl_surface_get_info(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(surface_ref->surf->flags);
}

static PyObject* sdl_surface_get_depth(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(format_ref->BytesPerPixel);
}

static PyObject* sdl_surface_get_depth_bits(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref =  surface_ref->surf->format;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(format_ref->BitsPerPixel);
}

static PyObject* sdl_surface_get_palette(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;
	SDL_Palette* pal_ref = format_ref->palette;

	PyObject* pal_list;
	int i;
		
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	if(!pal_ref)
	{
		PyErr_SetString(PyExc_RuntimeError, "Surface is not palettized\n");
		return NULL;
	}

	pal_list = PyList_New(pal_ref->ncolors);
	if(!pal_list)
		return NULL;

	for(i = 0;i < pal_ref->ncolors;i++)
	{
		PyObject* color_ref;
		SDL_Color* s_pal_ref = &pal_ref->colors[i];

		color_ref = Py_BuildValue("(bbb)", s_pal_ref->r, s_pal_ref->g,
			s_pal_ref->b);
		if(!color_ref)
		{
			Py_DECREF(pal_list);
			return NULL;
		}

		PyList_SET_ITEM(pal_list, i, color_ref);
	}

	return pal_list;
}

static PyObject* sdl_surface_pal_get_at(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;
	SDL_Palette* pal_ref = format_ref->palette;
	SDL_Color* s_pal_ref;
	int index;

	if(!PyArg_ParseTuple(args, "i", &index))
		return NULL;

	if(!pal_ref)
	{
		PyErr_SetString(PyExc_RuntimeError, "Surface is not palettized\n");
		return NULL;
	}

	if(index >= pal_ref->ncolors)
	{
		PyErr_SetString(PyExc_IndexError, "index out of bounds");
		return NULL;
	}

	s_pal_ref = &pal_ref->colors[index];
	
	return Py_BuildValue("(bbb)", s_pal_ref->r, s_pal_ref->g, s_pal_ref->b);
}

static PyObject* sdl_surface_set_palette(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;
	SDL_Palette* pal_ref = format_ref->palette;
	SDL_Color* colors;
	PyObject* pal_list;
	int i, len;
	
	if(!PyArg_ParseTuple(args, "O!", &PyList_Type, &pal_list))
		return NULL;

	/* If this is a non-palettized surface, don't bother */
	if(!pal_ref)
	{
		PyErr_SetString(PyExc_RuntimeError, "Surface is not palettized\n");
		return NULL;
	}

	/* Only attempt to set as many colors as the palette can handle */
	len = min(pal_ref->ncolors, PyList_Size(pal_list));

	colors = Py_Malloc(len * sizeof(SDL_Color));
	if(!colors)
		return NULL;
	
	for(i = 0; i < len; i++)
	{
		PyObject* color_ref = PyList_GET_ITEM(pal_list, i);

		if(!PyTuple_Check(color_ref) || PyTuple_Size(color_ref) != 3)
		{
			Py_Free(colors);

			PyErr_SetString(PyExc_TypeError, 
				"takes a list of tuples of RGB components");
			return NULL;
		}

		colors[i].r = PyInt_AsLong(PyTuple_GET_ITEM(color_ref, 0));
		colors[i].g = PyInt_AsLong(PyTuple_GET_ITEM(color_ref, 1));
		colors[i].b = PyInt_AsLong(PyTuple_GET_ITEM(color_ref, 2));
	}

	SDL_SetColors(surface_ref->surf, colors, 0, len);

	Py_Free(colors);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_surface_pal_set_at(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_PixelFormat* format_ref = surface_ref->surf->format;
	SDL_Palette* pal_ref = format_ref->palette;
	SDL_Color s_color;
	int index;
	Uint8 r, g, b;

	if(!PyArg_ParseTuple(args, "i(bbb)", &index, &r, &g, &b))
		return NULL;

	if(!pal_ref)
	{
		PyErr_SetString(PyExc_RuntimeError, "Surface is not palettized\n");
		return NULL;
	}

	if(index >= pal_ref->ncolors)
	{
		PyErr_SetString(PyExc_IndexError, "index out of bounds");
		return NULL;
	}

	s_color.r = r;
	s_color.g = g;
	s_color.b = b;

	SDL_SetColors(surface_ref->surf, &s_color, index, 1);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_surface_fill_rect(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	SDL_Rect rect;
	Uint32 color;
	
	if(!PyArg_ParseTuple(args, "(hhhh)i",
		&rect.x, &rect.y, &rect.w, &rect.h, &color))
		return NULL;
			
	return PyInt_FromLong(SDL_FillRect(surface_ref->surf, &rect,color));
}

static PyObject* sdl_surface_flip(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(SDL_Flip(surface_ref->surf));
}

static PyObject* sdl_surface_set_colorkey(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	Uint32 flags = 0, key = 0;

	if(!PyArg_ParseTuple(args, "|ii", &flags, &key))
		return NULL;
	
	return PyInt_FromLong(SDL_SetColorKey(surface_ref->surf, flags, key));
}

static PyObject* sdl_surface_set_alpha(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	Uint32 flags = 0;
	Uint8 alpha = 0;

	if(!PyArg_ParseTuple(args, "|ib", &flags, &alpha))
		return NULL;

	return PyInt_FromLong(SDL_SetAlpha(surface_ref->surf, flags, alpha));
}

static PyObject* sdl_surface_set_clip(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	int minx, miny, maxx, maxy;

	if(!PyArg_ParseTuple(args, "(iiii)", &minx, &miny, &maxx, &maxy))
		return NULL;

	SDL_SetClipping(surface_ref->surf, miny, minx, maxy, maxx);
	
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_surface_convert(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	Surface_Object* src_ref;
	Uint32 flags;
	
	if(!PyArg_ParseTuple(args, "O!i", &Surface_Type, &src_ref, &flags))
		return NULL;
		
	return sdl_surface_NEW(
		SDL_ConvertSurface(surface_ref->surf, src_ref->surf->format, flags));
}

static PyObject* sdl_surface_blit(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	Surface_Object* src_ref;
	SDL_Rect dest_rect;
	SDL_Rect src_rect;

	if(!PyArg_ParseTuple(args, "O!(hhhh)(hhhh)", &Surface_Type, &src_ref,
		&src_rect.x, &src_rect.y, &src_rect.w, &src_rect.h,
		&dest_rect.x, &dest_rect.y, &dest_rect.w, &dest_rect.h))
		return NULL;

	return PyInt_FromLong(
		SDL_BlitSurface(src_ref->surf, &src_rect,
			surface_ref->surf, &dest_rect));

}

static PyObject* sdl_surface_convert_display(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	if(!PyArg_ParseTuple(args, ""))
		return NULL;
	return sdl_surface_NEW(SDL_DisplayFormat(surface_ref->surf));
}

static PyObject* sdl_surface_save_bmp(PyObject* self, PyObject* args)
{
	Surface_Object* surface_ref = (Surface_Object*)self;
	PyObject* arg_ref;
	RW_Object* ops_ref;
	int status;
	
	if(!PyArg_ParseTuple(args, "O", &arg_ref))
		return NULL;

	ops_ref = rw_NEW(arg_ref, "wb");
	status = SDL_SaveBMP_RW(surface_ref->surf, (SDL_RWops*)ops_ref, 0);
	rw_DEL(ops_ref);

	return PyInt_FromLong(status);
}

/* Font constructors, destructors, methods, ... */

static PyObject* sdl_font_NEW(TTF_Font* font)
{
	Font_Object* font_ref;
	
	if(!font)
	{
		PyErr_SetString(PyExc_RuntimeError, "unable to load font.");
		return NULL;
	}

	font_ref = PyObject_NEW(Font_Object, &Font_Type);
	if(!font_ref)
		return NULL;

	font_ref->font = font;

	return (PyObject*)font_ref;
}

static void sdl_font_dealloc(PyObject* self)
{
	Font_Object* font_ref = (Font_Object*)self;
	
	if(video_is_initialized && sdl_is_initialized)
		TTF_CloseFont(font_ref->font);

	PyMem_DEL(self);
}

static PyObject* sdl_font_getattr(PyObject* self, char* attrname)
{
	if(video_is_initialized && sdl_is_initialized)
		return Py_FindMethod(sdl_font__builtins__, self, attrname);

	PyErr_SetString(PyExc_NameError, attrname);
	return NULL; 
}

static PyObject* sdl_font_get_style(PyObject* self, PyObject* args)
{
	Font_Object* font_ref = (Font_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(TTF_GetFontStyle(font_ref->font));
}

static PyObject* sdl_font_set_style(PyObject* self, PyObject* args)
{
	Font_Object* font_ref = (Font_Object*)self;
	int style;

	if(!PyArg_ParseTuple(args, "i", &style))
		return NULL;

	TTF_SetFontStyle(font_ref->font, style);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_font_get_descent(PyObject* self, PyObject* args)
{
	Font_Object* font_ref = (Font_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(TTF_FontDescent(font_ref->font));
}

static PyObject* sdl_font_get_skip(PyObject* self, PyObject* args)
{
	Font_Object* font_ref = (Font_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(TTF_FontLineSkip(font_ref->font));
}

static PyObject* sdl_font_get_height(PyObject* self, PyObject* args)
{
	Font_Object* font_ref = (Font_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(TTF_FontHeight(font_ref->font));
}

/* internal function */
static PyObject* sdl_font_get_size_i(PyObject* self, PyObject* args, int mode)
{
	Font_Object* font_ref = (Font_Object*)self;
	int width, height;
	char* text;

	if(!PyArg_ParseTuple(args, "s", &text))
		return NULL;

	switch(mode)
	{
		case RENDER_LATIN:
			TTF_SizeText(font_ref->font, text, &width, &height);
			break;
		case RENDER_UTF8:
			TTF_SizeUTF8(font_ref->font, text, &width, &height);
			break;
	}

	return Py_BuildValue("(ii)", width, height);
}

static PyObject* sdl_font_get_utf8_size(PyObject* self, PyObject* args)
{
	return sdl_font_get_size_i(self, args, RENDER_UTF8);
}

static PyObject* sdl_font_get_text_size(PyObject* self, PyObject* args)
{
	return sdl_font_get_size_i(self, args, RENDER_LATIN);
}

static PyObject* sdl_font_render(PyObject* self, PyObject* args)
{
	return sdl_font_render_i(self, args, RENDER_LATIN);
}

static PyObject* sdl_font_render_blended(PyObject* self, PyObject* args)
{
	return sdl_font_render_i(self, args, RENDER_LATIN_BLENDED);
}

static PyObject* sdl_font_render_solid(PyObject* self, PyObject* args)
{
	return sdl_font_render_i(self, args, RENDER_LATIN_SOLID);
}

static PyObject* sdl_font_render_utf8(PyObject* self, PyObject* args)
{
	return sdl_font_render_i(self, args, RENDER_UTF8);
}

static PyObject* sdl_font_render_utf8_blended(PyObject* self, PyObject* args)
{
	return sdl_font_render_i(self, args, RENDER_UTF8_BLENDED);
}

static PyObject* sdl_font_render_utf8_solid(PyObject* self, PyObject* args)
{
	return sdl_font_render_i(self, args, RENDER_UTF8_SOLID);
}

/* Internal function. */
static PyObject* sdl_font_render_i(PyObject* self, PyObject* args, int mode)
{
	Font_Object* font_ref = (Font_Object*)self;
	SDL_Surface* s_surface_ref;
	SDL_Color fg, bg;
	char* text;

	switch(mode)
	{
		case RENDER_LATIN:
		case RENDER_UTF8:
		{
			if(!PyArg_ParseTuple(args, "s(bbb)(bbb)", &text, &fg.r, &fg.g, &fg.b,
				&bg.r, &bg.g, &bg.b))
			{
				return NULL;
			}

			break;
		}
		case RENDER_LATIN_SOLID:
		case RENDER_UTF8_SOLID:
		case RENDER_LATIN_BLENDED:
		case RENDER_UTF8_BLENDED:
		{
			if(!PyArg_ParseTuple(args, "s(bbb)", &text, &fg.r, &fg.g, &fg.b))
				return NULL;

			break;
		}
	}
	
	switch(mode)
	{
		case RENDER_LATIN:
			s_surface_ref = TTF_RenderText(font_ref->font, text, fg, bg);
			break;
		case RENDER_LATIN_BLENDED:
			s_surface_ref = TTF_RenderText_Blended(font_ref->font, text, fg);
			break;
		case RENDER_LATIN_SOLID:
			s_surface_ref = TTF_RenderText_Solid(font_ref->font, text, fg);
			break;
		case RENDER_UTF8:
			s_surface_ref = TTF_RenderUTF8(font_ref->font, text, fg, bg);
		case RENDER_UTF8_BLENDED:
			s_surface_ref = TTF_RenderUTF8_Blended(font_ref->font, text, fg);
			break;
		case RENDER_UTF8_SOLID:
			s_surface_ref = TTF_RenderUTF8_Solid(font_ref->font, text, fg);
			break;
		default:
			return NULL;
	}

	if(!s_surface_ref)
	{
		PyErr_SetString(PyExc_RuntimeError, "Unable to render text.");
		return NULL;
	}

	return sdl_surface_NEW(s_surface_ref);
}

/* Audio related code */

/* Audio device related methods, constructors, and destructors */
static void sdl_audiodev_dealloc(PyObject* self)
{
	if(audio_is_initialized && sdl_is_initialized)
	{
		if(audio_is_open == 1)
		{
			audio_is_open = 0;
			Mix_CloseAudio();
		}
		else
		if(audio_is_open == -1)
			audio_is_open = 1;
	}
	PyMem_DEL(self);
}

static PyObject* sdl_audiodev_getattr(PyObject* self, char* attrname)
{
	if(audio_is_initialized && sdl_is_initialized)
		return Py_FindMethod(sdl_audiodev__builtins__, self, attrname);

	PyErr_SetString(PyExc_NameError, attrname);
	return NULL;
}

static PyObject* sdl_audiodev_play(PyObject* self, PyObject* args)
{
	Sound_Object* sound_ref;
	int channel, loops = 0, ticks = -1;

	if(!PyArg_ParseTuple(args, "iO!|ii", &channel, &Sound_Type, &sound_ref,
		&loops, &ticks))
	{
		return NULL;
	}

	return PyInt_FromLong(
		Mix_PlayChannelTimed(channel, sound_ref->sound, loops, ticks));
}

static PyObject* sdl_audiodev_play_music(PyObject* self, PyObject* args)
{
	Music_Object* music_ref;
	int loops = 0;

	if(!PyArg_ParseTuple(args, "O!|i", &Music_Type, &music_ref, &loops))
		return NULL;

	return PyInt_FromLong(Mix_PlayMusic(music_ref->music, loops));
}

static PyObject* sdl_audiodev_alloc_channels(PyObject* self, PyObject* args)
{
	int channels;

	if(!PyArg_ParseTuple(args, "i", &channels))
		return NULL;

	return PyInt_FromLong(Mix_AllocateChannels(channels));
}

static PyObject* sdl_audiodev_set_volume(PyObject* self, PyObject* args)
{
	int channel, volume;

	if(!PyArg_ParseTuple(args, "ii", &channel, &volume))
		return NULL;

	Mix_Volume(channel, volume);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_audiodev_get_volume(PyObject* self, PyObject* args)
{
	int channel;

	if(!PyArg_ParseTuple(args, "i", &channel))
		return NULL;

	return PyInt_FromLong(Mix_Volume(channel, -1));
}

static PyObject* sdl_audiodev_set_music_volume(PyObject* self, PyObject* args)
{
	int volume;

	if(!PyArg_ParseTuple(args, "i", &volume))
		return NULL;

	Mix_VolumeMusic(volume);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_audiodev_get_music_volume(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(Mix_VolumeMusic(-1));
}

static PyObject* sdl_audiodev_fade_in(PyObject* self, PyObject* args)
{
	int channel, ms, loops = 0, ticks = -1;
	Sound_Object* sound_ref;
	
	if(!PyArg_ParseTuple(args, "iO!i|ii", &channel, &Sound_Type, &sound_ref,
		&ms, &loops, &ticks))
	{
		return NULL;
	}

	return PyInt_FromLong(
		Mix_FadeInChannelTimed(channel, sound_ref->sound, loops, ms, ticks));
}

static PyObject* sdl_audiodev_fade_in_music(PyObject* self, PyObject* args)
{
	Music_Object* music_ref;
	int ms, loops  = 0;

	if(!PyArg_ParseTuple(args, "O!i|i", &Music_Type, &music_ref, &ms, &loops))
		return NULL;

	return PyInt_FromLong(
		Mix_FadeInMusic(music_ref->music, loops, ms));
}

static PyObject* sdl_audiodev_fade_out(PyObject* self, PyObject* args)
{
	int channel, ms;

	if(!PyArg_ParseTuple(args, "ii", &channel, &ms))
		return NULL;

	return PyInt_FromLong(Mix_FadeOutChannel(channel, ms));
}

static PyObject* sdl_audiodev_fade_out_music(PyObject* self, PyObject* args)
{
	int ms;

	if(!PyArg_ParseTuple(args, "i", &ms))
		return NULL;

	return PyInt_FromLong(Mix_FadeOutMusic(ms));
}

static PyObject* sdl_audiodev_halt(PyObject* self, PyObject* args)
{
	int channel;

	if(!PyArg_ParseTuple(args, "i", &channel))
		return NULL;

	return PyInt_FromLong(Mix_HaltChannel(channel));
}

static PyObject* sdl_audiodev_halt_music(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(Mix_HaltMusic());
}

static PyObject* sdl_audiodev_expire(PyObject* self, PyObject* args)
{
	int channel, ticks;

	if(!PyArg_ParseTuple(args, "ii", &channel, &ticks))
		return NULL;

	return PyInt_FromLong(Mix_ExpireChannel(channel, ticks));
}

static PyObject* sdl_audiodev_pause(PyObject* self, PyObject* args)
{
	int channel;

	if(!PyArg_ParseTuple(args, "i", &channel))
		return NULL;

	Mix_Pause(channel);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_audiodev_pause_music(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	Mix_PauseMusic();

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_audiodev_resume(PyObject* self, PyObject* args)
{
	int channel;

	if(!PyArg_ParseTuple(args, "i", &channel))
		return NULL;

	Mix_Resume(channel);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_audiodev_resume_music(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	Mix_ResumeMusic();

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_audiodev_is_paused(PyObject* self, PyObject* args)
{
	int channel;

	if(!PyArg_ParseTuple(args, "i", &channel))
		return NULL;

	return PyInt_FromLong(Mix_Paused(channel));
}

static PyObject* sdl_audiodev_is_music_paused(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(Mix_PausedMusic());
}

static PyObject* sdl_audiodev_rewind_music(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	Mix_RewindMusic();

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_audiodev_is_playing(PyObject* self, PyObject* args)
{
	int channel;

	if(!PyArg_ParseTuple(args, "i", &channel))
		return NULL;

	return PyInt_FromLong(Mix_Playing(channel));
}

static PyObject* sdl_audiodev_is_music_playing(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(Mix_PlayingMusic());
}

static PyObject* sdl_audiodev_fading(PyObject* self, PyObject* args)
{
	int channel;

	if(!PyArg_ParseTuple(args, "i", &channel))
		return NULL;

	return PyInt_FromLong(Mix_FadingChannel(channel));
}

static PyObject* sdl_audiodev_fading_music(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(Mix_FadingMusic());
}

static PyObject* sdl_audiodev_get_freq(PyObject* self, PyObject* args)
{
	AudioDev_Object* audiodev_ref = (AudioDev_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(audiodev_ref->freq);
}

static PyObject* sdl_audiodev_get_format(PyObject* self, PyObject* args)
{
	AudioDev_Object* audiodev_ref = (AudioDev_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(audiodev_ref->format);
}

static PyObject* sdl_audiodev_get_channels(PyObject* self, PyObject* args)
{
	AudioDev_Object* audiodev_ref = (AudioDev_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(audiodev_ref->channels);
}

/* Audio buffer related methods, constructors, and destructors */

static PyObject* sdl_sound_NEW(Mix_Chunk* chunk_ref)
{
	Sound_Object* sound_ref;

	if(!chunk_ref)
	{
		PyErr_SetString(PyExc_RuntimeError, "unable to acquire audio data");
		return NULL;
	}

	sound_ref = PyObject_NEW(Sound_Object, &Sound_Type);
	if(!sound_ref)
		return NULL;

	sound_ref->sound = chunk_ref;

	return (PyObject*)sound_ref;
}

static void sdl_sound_dealloc(PyObject* self)
{
	Sound_Object* sound_ref = (Sound_Object*)self;
	
	if(audio_is_initialized && sdl_is_initialized)
		Mix_FreeChunk(sound_ref->sound);
	
	PyMem_DEL(self);
}


static PyObject* sdl_sound_getattr(PyObject* self, char* attrname)
{
	if(audio_is_initialized && sdl_is_initialized)
		return Py_FindMethod(sdl_sound__builtins__, self, attrname);

	PyErr_SetString(PyExc_NameError, attrname);
	return NULL;	
}

static PyObject* sdl_sound_get_len(PyObject* self, PyObject* args)
{
	Sound_Object* sound_ref = (Sound_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(sound_ref->sound->alen);
}

static PyObject* sdl_sound_set_volume(PyObject* self, PyObject* args)
{
	Sound_Object* sound_ref = (Sound_Object*)self;
	int volume;

	if(!PyArg_ParseTuple(args, "i", &volume))
		return NULL;

	Mix_VolumeChunk(sound_ref->sound, volume);

	Py_INCREF(Py_None);
	return Py_None;
}


static PyObject* sdl_sound_get_volume(PyObject* self, PyObject* args)
{
	Sound_Object* sound_ref = (Sound_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(Mix_VolumeChunk(sound_ref->sound, -1));
}

/* Music methods and functions */
static PyObject* sdl_music_NEW(Mix_Music* m_music_ref)
{
	Music_Object* music_ref;

	if(!m_music_ref)
	{
		PyErr_SetString(PyExc_RuntimeError, "unable to acquire music");
		return NULL;
	}

	music_ref = PyObject_NEW(Music_Object, &Music_Type);
	if(!music_ref)
		return NULL;

	music_ref->music = m_music_ref;

	return (PyObject*)music_ref;
}

static void sdl_music_dealloc(PyObject* self)
{
	Music_Object* music_ref = (Music_Object*)self;

	if(audio_is_initialized && sdl_is_initialized)
		Mix_FreeMusic(music_ref->music);

	PyMem_DEL(self);
}

static PyObject* sdl_music_getattr(PyObject* self, char* attrname)
{
	if(audio_is_initialized && sdl_is_initialized)
		return Py_FindMethod(sdl_music__builtins__, self, attrname);

	PyErr_SetString(PyExc_NameError, attrname);
	return NULL;
}

/* global namespace audio functions */

static PyObject* sdl_audio_open(PyObject* self, PyObject* args)
{
	int freq;
	Uint16 format;
	int channels;
	int chunksize = 4096;
	AudioDev_Object* audiodev_ref;

	if(!PyArg_ParseTuple(args, "ihi|i", &freq, &format, &channels, &chunksize))
		return NULL;

	AUDIO_INIT_CHECK

	audiodev_ref = PyObject_NEW(AudioDev_Object, &AudioDev_Type);
	if(!audiodev_ref)
		return NULL;

	if(audio_is_open == 1)
	{
		Mix_CloseAudio();
		audio_is_open = -1;
	}
	else
		audio_is_open = 1;

	if(Mix_OpenAudio(freq, format, channels, chunksize) == -1)
	{
		PyMem_DEL(audiodev_ref);
		return PyInt_FromLong(-1);
	}

	Mix_QuerySpec(&audiodev_ref->freq, &audiodev_ref->format, 
		&audiodev_ref->channels);

	return (PyObject*)audiodev_ref;

}

static PyObject* sdl_sound_load(PyObject* self, PyObject* args)
{
	RW_Object* rw_ops;
	PyObject* arg_ref;
	PyObject* sound_ref;
	
	if(!PyArg_ParseTuple(args, "O", &arg_ref))
		return NULL;

	AUDIO_INIT_CHECK

	rw_ops = rw_NEW(arg_ref, "rb");
	if(!rw_ops)
		return NULL;

	sound_ref = sdl_sound_NEW(Mix_LoadWAV_RW((SDL_RWops*)rw_ops, 0));
	rw_DEL(rw_ops);

	return sound_ref;
}

static PyObject* sdl_music_load(PyObject* self, PyObject* args)
{
	char* file;
	/* This is only temporary, until I write a patch for SDL_mixer, to
	 * use the SDL_RWops structure, instead of a filename
	*/

	if(!PyArg_ParseTuple(args, "s", &file))
		return NULL;

	AUDIO_INIT_CHECK

	return sdl_music_NEW(Mix_LoadMUS(file));
}

/* CD related code */

static PyObject* sdl_cd_NEW(SDL_CD* cdrom)
{
	CD_Object* cd;

	if(!cdrom)
	{
		PyErr_SetString(PyExc_RuntimeError, "unable to acquire SDL CD");
		return NULL;
	}
	
	cd = PyObject_NEW(CD_Object, &CD_Type);
	if(!cd)
		return NULL;

	cd->cd = cdrom;

	return (PyObject*)cd;
}

static PyObject* sdl_cdrom_open(PyObject* self, PyObject* args)
{
	int id;
	
	if(!PyArg_ParseTuple(args, "i", &id))
		return NULL;

	CDROM_INIT_CHECK

	return sdl_cd_NEW(SDL_CDOpen(id));
}

static void sdl_cd_dealloc(PyObject* self)
{
	CD_Object* cd_ref = (CD_Object*)self;

	if(sdl_is_initialized && cdrom_is_initialized)
		SDL_CDClose(cd_ref->cd);
	PyMem_DEL(self);	
}

static PyObject* sdl_cd_getattr(PyObject* self, char* attrname)
{
	if(sdl_is_initialized && cdrom_is_initialized)
		return Py_FindMethod(sdl_cd__builtins__, self, attrname);

	PyErr_SetString(PyExc_NameError, attrname);
	return NULL;
}

static int sdl_cd_seq_len(PyObject* self)
{
	CD_Object* cd_ref = (CD_Object*)self;

	if(!sdl_is_initialized || !cdrom_is_initialized)
	{
		PyErr_SetString(PyExc_RuntimeError, "SDL has shut down.");
		return -1;
	}
	
	if(!CD_INDRIVE(SDL_CDStatus(cd_ref->cd)))
	{
		PyErr_SetString(PyExc_RuntimeError, "No CD present");
		return -1;
	}

	return cd_ref->cd->numtracks;
}

static PyObject* sdl_cd_seq_get(PyObject* self, int index)
{
	CD_Object* cd_ref = (CD_Object*)self;
   SDL_CD* s_cd_ref = cd_ref->cd;
	SDL_CDtrack* s_track_ref;

	if(!sdl_is_initialized || !cdrom_is_initialized)
	{
		PyErr_SetString(PyExc_RuntimeError, "SDL has shut down.");
		return NULL;
	}

	if(!CD_INDRIVE(SDL_CDStatus(s_cd_ref)) || index >= s_cd_ref->numtracks
		|| index < 0)
	{
		return PyInt_FromLong(-1);
	}

	s_track_ref = &s_cd_ref->track[index];
																			 
	return Py_BuildValue("(iii)", s_track_ref->type, s_track_ref->length,
		s_track_ref->offset);	
}

static PyObject* sdl_cd_seq_get_slice(PyObject* self, int start, int end)
{
	CD_Object* cd_ref = (CD_Object*)self;
	SDL_CD* s_cd_ref = cd_ref->cd;
	PyObject* track_tuple;
	int count;
	int i;

	if(!sdl_is_initialized || !cdrom_is_initialized)
	{
		PyErr_SetString(PyExc_RuntimeError, "SDL has shut down.");
		return NULL;
	}
	
	i = min(start,end);
	end = max(start,end);
	start = i;

	if(start < 0)
	{
		PyErr_SetString(PyExc_IndexError, "Index out of range.");
		return NULL;
	}
	
	if(CD_INDRIVE(SDL_CDStatus(s_cd_ref)) <= 0)
	{
		PyErr_SetString(PyExc_RuntimeError, "CD unavailable");
		return NULL;
	}

	/* If end is greater than the real number of tracks, trunctate it.
	 * This is done because of how Python handles slicing
	*/
	end = min(end, s_cd_ref->numtracks);
	count = end - start;

	track_tuple = PyTuple_New(count);
	if(!track_tuple)
		return NULL;

	for(i = 0;i < count;i++)
	{
		PyObject* elem_tuple;
		SDL_CDtrack* s_track_ref = &s_cd_ref->track[i + start];

		elem_tuple = Py_BuildValue("(iii)",
			s_track_ref->type, s_track_ref->length, s_track_ref->offset);
		if(!elem_tuple)
		{
			Py_DECREF(track_tuple);
			return NULL;
		}

		PyTuple_SET_ITEM(track_tuple, i, elem_tuple);
	}
	return track_tuple; 	
}

static PyObject* sdl_cdrom_get_count(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	CDROM_INIT_CHECK

	return PyInt_FromLong(SDL_CDNumDrives());
}

static PyObject* sdl_cdrom_get_name(PyObject* self, PyObject* args)
{
	int drive;
	
	if(!PyArg_ParseTuple(args, "i", &drive))
		return NULL;

	CDROM_INIT_CHECK

	return PyString_FromString(SDL_CDName(drive));
}

static PyObject* sdl_cd_play_tracks(PyObject* self, PyObject* args)
{
	int start_track, start_frame, ntracks, nframes;
	CD_Object* cd_ref = (CD_Object*)self;

	if(!PyArg_ParseTuple(args, "iiii", &start_track, &start_frame, &ntracks,
		&nframes	))
		return NULL;
		
	SDL_CDStatus(cd_ref->cd);
		
	return PyInt_FromLong(
		SDL_CDPlayTracks(cd_ref->cd, start_track, start_frame, ntracks, nframes));
}

static PyObject* sdl_cd_play(PyObject* self, PyObject* args)
{
	int start_frame, nframes;
	CD_Object* cd_ref = (CD_Object*)self;
	
	if(!PyArg_ParseTuple(args, "ii", &start_frame, &nframes))
		return NULL;

	SDL_CDStatus(cd_ref->cd);

	return PyInt_FromLong(SDL_CDPlay(cd_ref->cd, start_frame, nframes));
}

static PyObject* sdl_cd_pause(PyObject* self, PyObject* args)
{
	CD_Object* cd_ref = (CD_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	if(SDL_CDStatus(cd_ref->cd) != CD_PLAYING)
		return PyInt_FromLong(-1);

	return PyInt_FromLong(SDL_CDPause(cd_ref->cd));
}

static PyObject* sdl_cd_resume(PyObject* self, PyObject* args)
{
	CD_Object* cd_ref = (CD_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	if(SDL_CDStatus(cd_ref->cd) != CD_PAUSED)
		return PyInt_FromLong(-1);

	return PyInt_FromLong(SDL_CDResume(cd_ref->cd));
}

static PyObject* sdl_cd_stop(PyObject* self, PyObject* args)
{
	CD_Object* cd_ref = (CD_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	if(SDL_CDStatus(cd_ref->cd) < CD_PLAYING)
		return PyInt_FromLong(-1);

	return PyInt_FromLong(SDL_CDStop(cd_ref->cd));
}

static PyObject* sdl_cd_eject(PyObject* self, PyObject* args)
{
	CD_Object* cd_ref = (CD_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	if(SDL_CDStatus(cd_ref->cd) <= 0 )
		return PyInt_FromLong(-1);

	return PyInt_FromLong(SDL_CDEject(cd_ref->cd));
}

static PyObject* sdl_cd_get_status(PyObject* self, PyObject* args)
{
	CD_Object* cd_ref = (CD_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(SDL_CDStatus(cd_ref->cd));
}

static PyObject* sdl_cd_get_cur_track(PyObject* self, PyObject* args)
{
	CD_Object* cd_ref = (CD_Object*)self;
	SDL_CD* s_cd_ref = cd_ref->cd;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	if(SDL_CDStatus(s_cd_ref) <= 1)
		return PyInt_FromLong(-1);

	return PyInt_FromLong(s_cd_ref->cur_track);
}

static PyObject* sdl_cd_get_cur_frame(PyObject* self, PyObject* args)
{
	CD_Object* cd_ref = (CD_Object*)self;
	SDL_CD* s_cd_ref = cd_ref->cd;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	if(SDL_CDStatus(s_cd_ref) <= 1)
		return PyInt_FromLong(-1);

	return PyInt_FromLong(s_cd_ref->cur_frame);
}

static PyObject* sdl_cd_has_cd(PyObject* self, PyObject* args)
{
	CD_Object* cd_ref = (CD_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(CD_INDRIVE(SDL_CDStatus(cd_ref->cd)));
}


/* Event related code */

static PyObject* sdl_event_NEW(SDL_Event* event)
{
	Event_Object* event_ref;

	if(!event)
	{
		PyErr_SetString(PyExc_RuntimeError, "Unable to allocate event object");
		return NULL;
	}

	event_ref = PyObject_NEW(Event_Object, &Event_Type);
	if(!event_ref)
		return NULL;

	event_ref->event = event;

	return (PyObject*)event_ref;
}

static PyObject* sdl_event_new(PyObject* self, PyObject* args)
{
	Uint8 event_type;
	SDL_Event* s_event_ref;

	if(!PyArg_ParseTuple(args, "b", &event_type))
		return NULL;

	EVENT_INIT_CHECK

	s_event_ref = Py_Malloc(sizeof(SDL_Event));
	if(!s_event_ref)
		return NULL;

	s_event_ref->type = event_type;
	return sdl_event_NEW(s_event_ref);
}

static void sdl_event_dealloc(PyObject* self)
{
	Event_Object* event_ref = (Event_Object*)self;
	
	Py_Free(event_ref->event);
	PyMem_DEL(self);
}

static PyObject* sdl_event_getattr(PyObject* self, char* attrname)
{
	Event_Object* event_ref = (Event_Object*)self;

	if(!sdl_is_initialized || !video_is_initialized)
	{
		PyErr_SetString(PyExc_NameError, attrname);
		return NULL;
	}

	switch(event_ref->event->type)
	{
		case SDL_ACTIVEEVENT:
			return Py_FindMethod(sdl_active_event__builtins__, self, attrname);
		case SDL_KEYDOWN:
		case SDL_KEYUP:
			return Py_FindMethod(sdl_keyboard_event__builtins__, self, attrname);
		case SDL_MOUSEMOTION:
			return Py_FindMethod(sdl_mouse_motion_event__builtins__, 
				self, attrname);
		case SDL_MOUSEBUTTONDOWN:
		case SDL_MOUSEBUTTONUP:
			return Py_FindMethod(sdl_mouse_button_event__builtins__,
				self, attrname);
		case SDL_JOYAXISMOTION:
			return Py_FindMethod(sdl_joy_axis_event__builtins__, self, attrname);
		case SDL_JOYBALLMOTION:
			return Py_FindMethod(sdl_joy_ball_event__builtins__, self, attrname);
		case SDL_JOYHATMOTION:
			return Py_FindMethod(sdl_joy_hat_event__builtins__, self, attrname);
		case SDL_JOYBUTTONDOWN:
		case SDL_JOYBUTTONUP:
			return Py_FindMethod(sdl_joy_button_event__builtins__, self, attrname);
		case SDL_RESIZABLE:
			return Py_FindMethod(sdl_resize_event__builtins__, self, attrname);
	}
	return Py_FindMethod(sdl_event__builtins__, self, attrname);
}

static PyObject* sdl_event_get_type(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(event_ref->event->type);
}

static PyObject* sdl_event_active_get_gain(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_ActiveEvent* s_event_ref = (SDL_ActiveEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->gain);
}

static PyObject* sdl_event_active_set_gain(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_ActiveEvent* s_event_ref = (SDL_ActiveEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, "b", &s_event_ref->gain))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_active_get_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_ActiveEvent* s_event_ref = (SDL_ActiveEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->state);
}

static PyObject* sdl_event_active_set_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_ActiveEvent* s_event_ref = (SDL_ActiveEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, "b", &s_event_ref->state))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_key_set_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_KeyboardEvent* s_event_ref = (SDL_KeyboardEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, "b", &s_event_ref->state))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_key_get_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_KeyboardEvent* s_event_ref = (SDL_KeyboardEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->state);
}

static PyObject* sdl_event_key_get_sym(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_KeyboardEvent* s_event_ref = (SDL_KeyboardEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->keysym.sym);
}

static PyObject* sdl_event_key_set_sym(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_KeyboardEvent* s_event_ref = (SDL_KeyboardEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, "i", &s_event_ref->keysym.sym))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_key_get_mod(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_KeyboardEvent* s_event_ref = (SDL_KeyboardEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->keysym.mod);
}

static PyObject* sdl_event_key_set_mod(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_KeyboardEvent* s_event_ref = (SDL_KeyboardEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, "i", &s_event_ref->keysym.mod))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_mouse_get_coords(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseMotionEvent* s_event_ref = (SDL_MouseMotionEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(hhhh)", 
		s_event_ref->x, s_event_ref->y,
		s_event_ref->xrel, s_event_ref->yrel);
}

static PyObject* sdl_event_mouse_set_coords(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseMotionEvent* s_event_ref = (SDL_MouseMotionEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, "(hhhh)", 
		&s_event_ref->x, &s_event_ref->y,
		&s_event_ref->xrel, &s_event_ref->yrel))
	{
		return NULL;
	}

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_mouse_get_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseMotionEvent* s_event_ref = (SDL_MouseMotionEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->state);
}

static PyObject* sdl_event_mouse_set_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseMotionEvent* s_event_ref = (SDL_MouseMotionEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, "b", &s_event_ref->state))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_button_get_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseButtonEvent* s_event_ref = (SDL_MouseButtonEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->state);
}

static PyObject* sdl_event_button_set_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseButtonEvent* s_event_ref = (SDL_MouseButtonEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "b", &s_event_ref->state))
		return NULL;
	
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_button_get_button(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseButtonEvent* s_event_ref = (SDL_MouseButtonEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->button);
}

static PyObject* sdl_event_button_set_button(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseButtonEvent* s_event_ref = (SDL_MouseButtonEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "b", &s_event_ref->button))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_button_get_coords(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseButtonEvent* s_event_ref = (SDL_MouseButtonEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(hh)", s_event_ref->x, s_event_ref->y);
}

static PyObject* sdl_event_button_set_coords(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_MouseButtonEvent* s_event_ref = (SDL_MouseButtonEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "(hh)", &s_event_ref->x, &s_event_ref->y))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_joy_axis_get_ids(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyAxisEvent* s_event_ref = (SDL_JoyAxisEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(bb)", s_event_ref->which, s_event_ref->axis);
}

static PyObject* sdl_event_joy_axis_set_ids(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyAxisEvent* s_event_ref = (SDL_JoyAxisEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "(bb)", &s_event_ref->which, &s_event_ref->axis))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_joy_axis_get_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyAxisEvent* s_event_ref = (SDL_JoyAxisEvent*)event_ref->event;
		
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->value);
}

static PyObject* sdl_event_joy_axis_set_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyAxisEvent* s_event_ref = (SDL_JoyAxisEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, "h", &s_event_ref->value))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_joy_ball_get_ids(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyBallEvent* s_event_ref = (SDL_JoyBallEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(bb)", s_event_ref->which, s_event_ref->ball);
}

static PyObject* sdl_event_joy_ball_set_ids(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyBallEvent* s_event_ref = (SDL_JoyBallEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "(bb)", &s_event_ref->which, &s_event_ref->ball))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_joy_ball_get_coords(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyBallEvent* s_event_ref = (SDL_JoyBallEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(hh)", s_event_ref->xrel, s_event_ref->yrel);
}

static PyObject* sdl_event_joy_ball_set_coords(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyBallEvent* s_event_ref = (SDL_JoyBallEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "(hh)", &s_event_ref->xrel, &s_event_ref->yrel))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_joy_hat_get_ids(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyHatEvent* s_event_ref = (SDL_JoyHatEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(bb)", s_event_ref->which, s_event_ref->hat);
}

static PyObject* sdl_event_joy_hat_set_ids(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyHatEvent* s_event_ref = (SDL_JoyHatEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "(bb)", &s_event_ref->which, &s_event_ref->hat))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_joy_hat_get_pos(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyHatEvent* s_event_ref = (SDL_JoyHatEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->value);
}

static PyObject* sdl_event_joy_hat_set_pos(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyHatEvent* s_event_ref = (SDL_JoyHatEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "b", &s_event_ref->value))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_jbutton_get_ids(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyButtonEvent* s_event_ref = (SDL_JoyButtonEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return Py_BuildValue("(bb)", s_event_ref->which, s_event_ref->button);
}

static PyObject* sdl_event_jbutton_set_ids(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyButtonEvent* s_event_ref = (SDL_JoyButtonEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "(bb)", &s_event_ref->which, 
		&s_event_ref->button))
	{
		return NULL;
	}

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_jbutton_get_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyButtonEvent* s_event_ref = (SDL_JoyButtonEvent*)event_ref->event;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->state);
}

static PyObject* sdl_event_jbutton_set_state(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_JoyButtonEvent* s_event_ref = (SDL_JoyButtonEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, "b", &s_event_ref->state))
		return NULL;

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_event_resize_get_height(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_ResizeEvent* s_event_ref = (SDL_ResizeEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->h);
}

static PyObject* sdl_event_resize_get_width(PyObject* self, PyObject* args)
{
	Event_Object* event_ref = (Event_Object*)self;
	SDL_ResizeEvent* s_event_ref = (SDL_ResizeEvent*)event_ref->event;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(s_event_ref->w);
}

static PyObject* sdl_events_pump(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	EVENT_INIT_CHECK

	SDL_PumpEvents();

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_events_wait(PyObject* self, PyObject* args)
{
	SDL_Event* s_event_ref;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	EVENT_INIT_CHECK

	s_event_ref = Py_Malloc(sizeof(SDL_Event));
	if(!s_event_ref)
		return NULL;

	if(SDL_WaitEvent(s_event_ref))
		return sdl_event_NEW(s_event_ref);

	return PyInt_FromLong(-1);
}

static PyObject* sdl_events_poll(PyObject* self, PyObject* args)
{
	SDL_Event* s_event_ref;
	
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	EVENT_INIT_CHECK

	s_event_ref = Py_Malloc(sizeof(SDL_Event));
	if(!s_event_ref)
		return NULL;

	if(SDL_PollEvent(s_event_ref))
		return sdl_event_NEW(s_event_ref);

	return PyInt_FromLong(-1);
}

static PyObject* sdl_events_peek(PyObject* self, PyObject* args)
{
	Uint32 mask;
	int count;
	
	if(!PyArg_ParseTuple(args, "ii", &mask, &count))
		return NULL;

	EVENT_INIT_CHECK

	return sdl_events_peep(count, mask, SDL_PEEKEVENT);
}

static PyObject* sdl_events_get(PyObject* self, PyObject* args)
{
	Uint32 mask;
	int count;

	if(!PyArg_ParseTuple(args, "ii", &mask, &count))
		return NULL;

	EVENT_INIT_CHECK

	return sdl_events_peep(count, mask, SDL_GETEVENT);
}

static PyObject* sdl_events_add(PyObject* self, PyObject* args)
{
	Event_Object* event_ref;
	
	if(!PyArg_ParseTuple(args, "O!", &Event_Type, &event_ref))
		return NULL;

	EVENT_INIT_CHECK

	if(SDL_PeepEvents(event_ref->event, 1, SDL_ADDEVENT, 0) == -1)
		return PyInt_FromLong(-1);

	return PyInt_FromLong(0);
}

static PyObject* sdl_events_peep(int count, Uint32 mask, SDL_eventaction action)
{
	SDL_Event* s_event_ref;
	PyObject* event_tuple;
	int i;

	s_event_ref = Py_Malloc(sizeof(SDL_Event) * count);
	if(!s_event_ref)
		return NULL;

	count = SDL_PeepEvents(s_event_ref, count, action, mask);
	if(count <= 0)
	{
		Py_Free(s_event_ref);
		return PyInt_FromLong(-1);
	}

	event_tuple = PyTuple_New(count);
	if(!event_tuple)
	{
		Py_Free(s_event_ref);
		return NULL;
	}
		
	for(i = 0;i < count;i++)
	{
		SDL_Event* i_event_ref;
		PyObject* event_elem;

		/* Allocate and copy each event into its own individual section of 
		 * memory, so it can be used in an Event_Object.
		*/
		i_event_ref = Py_Malloc(sizeof(SDL_Event));
		if(!i_event_ref)
		{
			Py_DECREF(event_tuple);
			Py_Free(s_event_ref);
		}
		memcpy(i_event_ref, &s_event_ref[i], sizeof(SDL_Event));

		event_elem = sdl_event_NEW(i_event_ref);
		if(!event_elem)
		{
			Py_DECREF(event_tuple);
			Py_Free(s_event_ref);
		}
		PyTuple_SET_ITEM(event_tuple, i, event_elem);
	}

	/* Free up the unused copy */
	Py_Free(s_event_ref);
	return event_tuple;
}

static PyObject* sdl_events_state(PyObject* self, PyObject* args)
{
	Uint8 event_type;
	int state;
	
	if(!PyArg_ParseTuple(args, "bi", &event_type, &state))
		return NULL;

	EVENT_INIT_CHECK

	return PyInt_FromLong(SDL_EventState(event_type, state));
}

static PyObject* sdl_events_key_repeat(PyObject* self, PyObject* args)
{
	int delay, interval;

	if(!PyArg_ParseTuple(args, "ii", &delay, &interval))
		return NULL;

	EVENT_INIT_CHECK

	SDL_EnableKeyRepeat(delay, interval);

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_events_get_key_state(PyObject* self, PyObject* args)
{
	int num_keys;
	Uint8* key_state;
	PyObject* key_tuple;
	int i;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	EVENT_INIT_CHECK

	key_state = SDL_GetKeyState(&num_keys);

	if(!key_state || !num_keys)
	{
		Py_INCREF(Py_None);
		return Py_None;
	}

	key_tuple = PyTuple_New(num_keys);
	if(!key_tuple)
		return NULL;

	for(i = 0;i < num_keys;i++)
	{
		PyObject* key_elem;
		
		key_elem = PyInt_FromLong(key_state[i]);
		if(!key_elem)
		{
			Py_DECREF(key_tuple);
			return NULL;
		}
		
		PyTuple_SET_ITEM(key_tuple, i, key_elem);
	}
	return key_tuple;
}

static PyObject* sdl_events_get_key_name(PyObject* self, PyObject* args)
{
	int key;
	
	if(!PyArg_ParseTuple(args, "i", &key))
		return NULL;

	EVENT_INIT_CHECK

	return PyString_FromString(SDL_GetKeyName(key));	
}

static PyObject* sdl_events_get_mod(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	EVENT_INIT_CHECK

	return PyInt_FromLong(SDL_GetModState());
}


/* Joystick related routines */

static PyObject* sdl_joy_NEW(SDL_Joystick* joy)
{
	Joystick_Object* joy_ref;

	if(!joy)
	{
		PyErr_SetString(PyExc_RuntimeError, "Unable to allocate SDL joystick.");
		return NULL;
	}

	joy_ref = PyObject_NEW(Joystick_Object, &Joystick_Type);
	if(!joy_ref)
		return NULL;

	joy_ref->joy = joy;

	return (PyObject*)joy_ref;
}

static void sdl_joy_dealloc(PyObject* self)
{
	Joystick_Object* joy_ref = (Joystick_Object*)self;

	if(sdl_is_initialized && joy_is_initialized)
	{
		SDL_JoystickClose(joy_ref->joy);
	}

	PyMem_DEL(self);
}

static PyObject* sdl_joy_getattr(PyObject* self, char* attrname)
{
	if(sdl_is_initialized && joy_is_initialized)
		return Py_FindMethod(sdl_joy__builtins__, self, attrname);

	PyErr_SetString(PyExc_NameError,	attrname);
	return NULL;
}

static PyObject* sdl_joy_open(PyObject* self, PyObject* args)
{
	int id;

	if(!PyArg_ParseTuple(args, "i", &id))
		return NULL;

	JOY_INIT_CHECK

	return sdl_joy_NEW(SDL_JoystickOpen(id));
}

static PyObject* sdl_joy_get_count(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	JOY_INIT_CHECK

	return PyInt_FromLong(SDL_NumJoysticks());
}

static PyObject* sdl_joy_get_name(PyObject* self, PyObject* args)
{
	int id;

	if(!PyArg_ParseTuple(args, "i", &id))
		return NULL;

	JOY_INIT_CHECK

	return PyString_FromString(SDL_JoystickName(id));
}

static PyObject* sdl_joy_is_opened(PyObject* self, PyObject* args)
{
	int id;
	
	if(!PyArg_ParseTuple(args, "i", &id))
		return NULL;

	JOY_INIT_CHECK

	return PyInt_FromLong(SDL_JoystickOpened(id));
}

static PyObject* sdl_joy_update(PyObject* self, PyObject* args)
{
	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	JOY_INIT_CHECK

	SDL_JoystickUpdate();

	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject* sdl_joy_event_state(PyObject* self, PyObject* args)
{
	int state;
	
	if(!PyArg_ParseTuple(args, "i", &state))
		return NULL;

	JOY_INIT_CHECK

	return PyInt_FromLong(SDL_JoystickEventState(state));
}

static PyObject* sdl_joy_get_id(PyObject* self, PyObject* args)
{
	Joystick_Object* joy_ref = (Joystick_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(SDL_JoystickIndex(joy_ref->joy));
}

static PyObject* sdl_joy_get_axes(PyObject* self, PyObject* args)
{
	Joystick_Object* joy_ref = (Joystick_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(SDL_JoystickNumAxes(joy_ref->joy));
}

static PyObject* sdl_joy_get_balls(PyObject* self, PyObject* args)
{
	Joystick_Object* joy_ref = (Joystick_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(SDL_JoystickNumBalls(joy_ref->joy));
}

static PyObject* sdl_joy_get_hats(PyObject* self, PyObject* args)
{
	Joystick_Object* joy_ref = (Joystick_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(SDL_JoystickNumHats(joy_ref->joy));
}

static PyObject* sdl_joy_get_buttons(PyObject* self, PyObject* args)
{
	Joystick_Object* joy_ref = (Joystick_Object*)self;

	if(!PyArg_ParseTuple(args, ""))
		return NULL;

	return PyInt_FromLong(SDL_JoystickNumButtons(joy_ref->joy));
}

static PyObject* sdl_joy_get_axis(PyObject* self, PyObject* args)
{
	Joystick_Object* joy_ref = (Joystick_Object*)self;
	int axis;

	if(!PyArg_ParseTuple(args, "i", &axis))
		return NULL;

	return PyInt_FromLong(SDL_JoystickGetAxis(joy_ref->joy, axis));
}

static PyObject* sdl_joy_get_hat(PyObject* self, PyObject* args)
{
	Joystick_Object* joy_ref = (Joystick_Object*)self;
	int hat;

	if(!PyArg_ParseTuple(args, "i", &hat))
		return NULL;

	return PyInt_FromLong(SDL_JoystickGetHat(joy_ref->joy, hat));
}

static PyObject* sdl_joy_get_button(PyObject* self, PyObject* args)
{
	Joystick_Object* joy_ref = (Joystick_Object*)self;
	int button;

	if(!PyArg_ParseTuple(args, "i", &button))
		return NULL;

	return PyInt_FromLong(SDL_JoystickGetButton(joy_ref->joy, button));
}

/* File related functions */

static RW_Object* rw_NEW(PyObject* src_obj, char* mode)
{
	RW_Object* rw_ref;

	if(!src_obj)
		return NULL;

	if(PyString_Check(src_obj))
		return rw_NEW(PyFile_FromString(PyString_AsString(src_obj), mode), NULL);

	rw_ref = (RW_Object*)Py_Malloc(sizeof(RW_Object));
	if(!rw_ref)
		return NULL;

	Py_INCREF(src_obj);
	rw_ref->obj = src_obj;
	
	if(PyFile_Check(src_obj))
	{
		SDL_RWops* ops_ref = SDL_RWFromFP(PyFile_AsFile(src_obj), 0);
		memcpy(&rw_ref->rw, ops_ref, sizeof(SDL_RWops));
		SDL_FreeRW(ops_ref);

		rw_ref->seek = NULL;
		rw_ref->tell = NULL;
		rw_ref->read = NULL;
		rw_ref->write = NULL;
		rw_ref->close = NULL;

		return rw_ref;
	}

	rw_ref->seek = PyObject_GetAttrString(src_obj, "seek");
	rw_ref->tell = PyObject_GetAttrString(src_obj, "tell");
	rw_ref->read = PyObject_GetAttrString(src_obj, "read");
	rw_ref->write = PyObject_GetAttrString(src_obj, "write");
	rw_ref->close = PyObject_GetAttrString(src_obj, "close");

	rw_ref->rw.seek = rw_seek;
	rw_ref->rw.read = rw_read;
	rw_ref->rw.write = rw_write;
	rw_ref->rw.close = rw_close;

	PyErr_Clear();

	return rw_ref;
}

static void rw_DEL(RW_Object* rw_ref)
{
	if(!rw_ref)
		return;

	Py_XDECREF(rw_ref->obj);
	Py_XDECREF(rw_ref->seek);
	Py_XDECREF(rw_ref->tell);
	Py_XDECREF(rw_ref->read);
	Py_XDECREF(rw_ref->write);
	Py_XDECREF(rw_ref->close);

	Py_Free(rw_ref);
}

static int rw_seek(SDL_RWops* context, int offset, int whence)
{
	RW_Object* rw_ref = (RW_Object*)context;
	PyObject* result;
	int retval;
	
	if(!rw_ref->seek || !rw_ref->tell)
		return -1;
	
	result = PyObject_CallFunction(rw_ref->seek, "ii", offset, 
		whence);
	if(!result)
		return -1;

	Py_DECREF(result);

	result = PyObject_CallFunction(rw_ref->tell, NULL);
	if(!result)
		return -1;

	retval = PyInt_AsLong(result);
	Py_DECREF(result);

	return retval;
}

static int rw_read(SDL_RWops* context, void* ptr, int size, int maxnum)
{
	RW_Object* rw_ref = (RW_Object*)context;
	PyObject* result;
	int retval;

	if(!rw_ref->read)
		return -1;

	result = PyObject_CallFunction(rw_ref->read, "i", size * maxnum);
	if(!result)
		return -1;
		
	if(!PyString_Check(result))
	{
		Py_DECREF(result);
		return -1;
	}
		
	retval = PyString_GET_SIZE(result);
	memcpy(ptr, PyString_AsString(result), retval);
	retval /= size;
		
	Py_DECREF(result);
	return retval;
}

static int rw_write(SDL_RWops* context, const void* ptr, int size, int num)
{
	RW_Object* rw_ref = (RW_Object*)context;
	PyObject* result;

	if(!rw_ref->write)
		return -1;

	result = PyObject_CallFunction(rw_ref->write, "s#", ptr, size * num);
	if(!result)
		return -1;

	Py_DECREF(result);
	return num;
}

/* This is guranteed to almost never be called */
static int rw_close(SDL_RWops* context)
{
	RW_Object* rw_ref = (RW_Object*)context;
	PyObject* result;

	if(!rw_ref->close)
		return -1;

	result = PyObject_CallFunction(rw_ref->close, NULL);
	if(!result)
		return -1;

	Py_DECREF(result);
	return 0;
}
