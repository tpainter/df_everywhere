#include <Python.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

#ifdef WIN32
	#include <windows.h>
#endif

#define INFO_HW_A 0
#define INFO_WM_A 1
#define INFO_BLT_HW 2
#define INFO_BLT_HW_CC 3
#define INFO_BLT_HW_A 4
#define INFO_BLT_SW 5
#define INFO_BLT_SW_CC 6
#define INFO_BLT_SW_A 7
#define INFO_BLT_FILL 8
#define INFO_MEM 9

#define IMAGE_BMP 0
#define IMAGE_PPM 1
#define IMAGE_PCX 2
#define IMAGE_GIF 3
#define IMAGE_JPEG 4
#define IMAGE_TIFF 5
#define IMAGE_PNG 6


#define RENDER_LATIN 0
#define RENDER_LATIN_BLENDED 1
#define RENDER_LATIN_SOLID 2
#define RENDER_UTF8 3
#define RENDER_UTF8_BLENDED 4
#define RENDER_UTF8_SOLID 5

static char sdl__name__[] = "sdl";
static char sdl__doc__[] = "This module provides a low level interface "
	"to the C SDL API.";

static PyObject* sdl_init(PyObject* self, PyObject* args);
static char sdl_init__doc__[] = 
	"init(flags) -> int\n"
	"This function loads and initiliazes the SDL library and subsystems\n"
	"arguments:\n"
	"INIT_VIDEO - video and event subsystems\n"
	"INIT_AUDIO - audio subsystem\n"
	"INIT_CDROM - cdrom subsystem\n"
	"INIT_JOYSTICK - joystick subsystem\n"
	"INIT_NOPARACHUTE - doesn't install fatal signal handler\n"
	"INIT_EVERYTHING - initialize all subsystems\n";
	
static PyObject* sdl_init_subsystem(PyObject* self, PyObject* args);
static char sdl_init_subsystem__doc__[] =
	"init_subsystem(flags) -> int\n"
	"This functions loads and initializes a specific component\n"
	"of the SDL library\n"
	"It takes the same arguments as init()\n";

static PyObject* sdl_quit_subsystem(PyObject* self, PyObject* args);
static char sdl_quit_subsystem__doc__[] =
	"quit_subsystem(flags) -> None\n"
	"This function unloads a specific component of the SDL library.\n"
	"It takes the same arguments as init()\n";

static PyObject* sdl_quit(PyObject* self, PyObject* args);
static char sdl_quit__doc__[] =
	"quit() -> None\n"
	"This function unloads the SDL library.";

static PyObject* sdl_get_app_state(PyObject* self, PyObject* args);
static char sdl_get_app_state__doc__[] =
	"get_app_state() -> int\n"
	"Returns the application state.\n"
	"Supported states:\n"
	"APPMOUSEFOCUS - has mouse coverage\n"
	"APPINPUTFOCUS - has input focus\n"
	"APPACTIVE - is active\n";

static PyObject* sdl_video_init(PyObject* self, PyObject* args);
static char sdl_video_init__doc__[] =
	"video_init(driver_name, flags) -> int\n"
	"This function initializes the video subsystem, and gathers information\n"
	"about the current video mode.";
	
static PyObject* sdl_video_quit(PyObject* self, PyObject* args);
static char sdl_video_quit__doc__[] =
	"video_quit() -> None\n"
	"This function shuts down the video subsystem.";

static PyObject* sdl_video_driver_name(PyObject* self, PyObject* args);
static char sdl_video_driver_name__doc__[] =
	"video_driver_name() -> string\n"
	"This function returns the name of the current video driver.";

static PyObject* sdl_video_get_surface(PyObject* self, PyObject* args);
static char sdl_video_get_surface__doc__[] =
	"video_get_surface() -> Surface\n"
	"This function returns the current display surface.";
	
static PyObject* sdl_video_set_mode(PyObject* self, PyObject* args);
static char sdl_video_set_mode__doc__[] =
	"video_get_mode(width, height, depth, flags) -> Surface\n"
	"This function creates and returns a framebuffer surface.";

static PyObject* sdl_video_mode_ok(PyObject* self, PyObject* args);
static char sdl_video_mode_ok__doc__[] =
	"video_mode_ok(width, height, depth, flags) -> int\n"
	"This function returns indicating whether or not the specified\n"
	"video mode is possible.\n"
	"It will return 0 to indicate the desired mode is not possible, or\n"
	"it will return the closest matching color depth at which the mode\n"
	"is possible. This may be the same as the requested depth.";

static PyObject* sdl_video_list_modes(PyObject* self, PyObject* args);
static char sdl_video_list_modes__doc__[] =
	"video_list_modes(depth, flags) -> [(x,y),...], 0, or -1\n"
	"This function returns a list of possible dimensions for a specified\n"
	"color depth, -1 if any dimension is possible, or 0 if none are.";

static PyObject* sdl_video_info(PyObject* self, PyObject* args);
static char sdl_video_info__doc__[] =
	"video_info(option) -> int\n"
	"This function is used to ask if hardware acceleration is allowed for\n"
	"certain operations, how much video memory is available, whether or not\n"
	"a window manager is available, or if a surface can be created in\n"
	"video memory.\n"
	"Supported arguments:\n"
	"INFO_HW_A - Ask if surfaces can be created in video memory\n"
	"INFO_WM_A - Ask if a window manager is present\n"
	"INFO_BLT_HW - Ask if blits from video -> video are accelerated\n"
	"INFO_BLT_HW_CC - blits from video -> video have accelerated colorkeys\n"
	"INFO_BLT_HW_A - blits from video -> video has accelerated alpha\n"
	"INFO_BLT_SW - blit from sysmem -> video are accelerated\n"
	"INFO_BLT_SW_CC - blit from sysmem -> video have accelerated colorkeys\n"
	"INFO_BLT_SW_A - blit from sysmem -> video has accelerated alpha\n"
	"INFO_BLT_FILL - Ask if accelerated color fill is supported\n"
	"INFO_MEM - Ask how much video memory is available\n"
	"INFO_DEPTH - Ask for the video colordepth in bits\n";

static PyObject* sdl_video_set_gl(PyObject* self, PyObject* args);
static char sdl_video_set_gl__doc__[] =
	"video_set_gl(attr,val) -> int\n"
	"Sets the desired GL attribute to the value specified.";

static PyObject* sdl_video_get_gl(PyObject* self, PyObject* args);
static char sdl_video_get_gl__doc__[] =
	"video_get_gl(attr) -> int\n"
	"Returns the given GL attribute's value.";

static PyObject* sdl_video_swap_gl(PyObject* self, PyObject* args);
static char sdl_video_swap_gl__doc__[] =
	"video_swap_gl() -> None\n"
	"Swaps the OpenGL buffers, if double buffering is enabled.";

static PyObject* sdl_wm_grab_input(PyObject* self, PyObject* args);
static char sdl_wm_grab_input__doc__[] =
	"wm_grab_input(mode) -> int\n"
	"This function sets the input grab behavior. It should be called\n"
	"after every video mode change, if you want non-standard behavior.";

static PyObject* sdl_wm_toggle_fullscreen(PyObject* self, PyObject* args);
static char sdl_wm_toggle_fullscreen__doc__[] =
	"wm_toggle_fullscreen(surface) -> int\n"
	"This function toggles fullscreen mode without modifying\n"
	"the contents of the surface.";

static PyObject* sdl_wm_iconify(PyObject* self, PyObject* args);
static char sdl_wm_iconify__doc__[] =
	"wm_iconify() -> int\n"
	"This function asks the WM, if any, to minimize the window.\n"
	"If successful, an event indicating that focus has been lost";

static PyObject* sdl_wm_set_icon(PyObject* self, PyObject* args);
static char sdl_wm_set_icon__doc__[] =
	"wm_set_icon(icon) -> void\n"
	"This function asks the WM, if any, to set the window icon to\n"
	"the surface object provided as an argument.";

static PyObject* sdl_wm_set_caption(PyObject* self, PyObject* args);
static char sdl_wm_set_caption__doc__[] =
	"wm_set_caption(title, icontext) -> None\n"
	"This function asks the WM, if any, to set the title and icon's names.";

static PyObject* sdl_wm_get_caption(PyObject* self, PyObject* args);
static char sdl_wm_get_caption__doc__[] =
	"wm_get_caption() -> (title, icontext)\n"
	"This function asks the WM, if any, for the title and icon's names.";

static PyObject* sdl_font_load(PyObject* self, PyObject* args);
static char sdl_font_load__doc__[] =
	"font_load(file, size) -> Font\n"
	"Returns a font object using the specified TTF font.";

static PyObject* sdl_image_load(PyObject* self, PyObject* args);
static char sdl_image_load__doc__[] =
	"image_load(file or file_object) -> Surface\n"
	"This function creates a Surface from an image stored in file.\n"
	"Or if a file object was passed, instead of a file name, a Surface\n"
	"is created from an image stored at the current position in the file.";

static PyObject* sdl_image_is(PyObject* self, PyObject* args);
static char sdl_image_is__doc__[] =
	"image_is(file or file_object, type) -> int\n"
	"Returns 1 if the content of the file or file object's location is an\n"
	"image in the specified format.\n"
	"Supported formats:\n"
	"IMAGE_BMP\n"
	"IMAGE_PPM\n"
	"IMAGE_PCX\n"
	"IMAGE_GIF\n"
	"IMAGE_JPEG\n"
	"IMAGE_TIFF\n"
	"IMAGE_PNG\n";

static PyObject* sdl_image_load_type(PyObject* self, PyObject* args);
static char sdl_image_load_type__doc__[] =
	"image_load_type(file or file object, type) -> Surface\n"
	"Allows the loading of a Surface, but with a specific loader.";

static PyObject* sdl_image_invert_alpha(PyObject* self, PyObject* args);
static char sdl_image_invert_alpha__doc__[] =
	"image_invert_alpha(on) -> int\n"
	"Inverts the alpha of a Surface for use with OpenGL.\n";

static PyObject* sdl_get_error(PyObject* self, PyObject* args);
static char sdl_get_error__doc__[] =
	"get_error() -> string\n"
	"Returns the current SDL error message.";

static PyObject* sdl_get_ticks(PyObject* self, PyObject* args);
static char sdl_get_ticks__doc__[] =
	"get_ticks() -> int\n"
	"Returns the number of milliseconds since the initialization of SDL.";

static PyObject* sdl_delay(PyObject* self, PyObject* args);
static char sdl_delay__doc__[] =
	"delay(milli) -> None\n"
	"Waits milli milliseconds, and then returns.";

static PyObject* sdl_cursor_show(PyObject* self, PyObject* args);
static char sdl_cursor_show__doc__[] =
	"cursor_show(state) -> bool\n"
	"Sets the state (on or off) of the cursor, and returns the previous state.";

static PyObject* sdl_mouse_warp(PyObject* self, PyObject* args);
static char sdl_mouse_warp__doc__[] =
	"mouse_warp(x, y) -> None\n"
	"Warps the mouse cursor to the specified position.";

/* surface object related prototypes and __doc__ strings */


static PyObject* sdl_surface_NEW(SDL_Surface* surf);

static PyObject* sdl_surface_new(PyObject* self,PyObject* args);
static char sdl_surface_new__doc__[] =
	"surface_new(flags, width, height, depth,\n"
	"\t(Rmask, Gmask, Bmask, Amask)) -> Surface\n"
	"This function allocates a surface object.";

/* sequence, destructor, and constructor function for Surface objects */

static PyObject* sdl_surface_seq_get(PyObject* self, int index);
static PyObject* sdl_surface_seq_get_slice(PyObject* self, int start, int end);
static int sdl_surface_seq_set(PyObject* self, int index, PyObject* value);
static int sdl_surface_seq_set_slice(PyObject* self, int start, int end,
	 PyObject* value);
static int sdl_surface_seq_len(PyObject* self);
static PyObject* sdl_surface_getattr(PyObject* self,char* attrname);
static void sdl_surface_dealloc(PyObject* self);

/* Surface object methods */

static PyObject* sdl_surface_get_at(PyObject* self, PyObject* args);
static char sdl_surface_get_at__doc__[] =
	"get_at(x, y) -> int\n"
	"Returns the pixel at the coordinates x, y.";

static PyObject* sdl_surface_set_at(PyObject* self, PyObject* args);
static char sdl_surface_set_at__doc__[] =
	"set_at(x, y, pixel) -> None\n"
	"Sets the pixel at the coordinates x, y to pixel.";

static PyObject* sdl_surface_get_height(PyObject* self,PyObject* args);
static char sdl_surface_get_height__doc__[] = 
	"get_height() -> int\n"
	"This function returns the height of a Surface.";
	
static PyObject* sdl_surface_get_width(PyObject* self, PyObject* args);
static char sdl_surface_get_width__doc__[] =
	"get_width() -> int\n"
	"This function returns the width of a Surface.";

static PyObject* sdl_surface_get_pitch(PyObject* self, PyObject* args);
static char sdl_surface_get_pitch__doc__[] =
	"get_pitch() -> int\n"
	"This function returns the pitch of a Surface.";

static PyObject* sdl_surface_map_rgb(PyObject* self, PyObject* args);
static char sdl_surface_map_rgb__doc__[] =
	"map_rgb((r, g, b)) -> int\n"
	"This function maps a RGB value to a Surface's pixel format.";

static PyObject* sdl_surface_get_rgb(PyObject* self, PyObject* args);
static char sdl_surface_get_rgb__doc__[] =
	"get_rgb(color) -> (r, g, b)\n"
	"This function returns the RGB components for a color\n"
	"using the Surface's pixel format.";

static PyObject* sdl_surface_lock(PyObject* self,PyObject* args);
static char sdl_surface_lock__doc__[] =
	"lock() -> int\n"
	"This function locks a surface object, so you can\naccess its pixel data.";

static PyObject* sdl_surface_unlock(PyObject* self, PyObject* args);
static char sdl_surface_unlock__doc__[] =
	"unlock() -> None\n"
	"This function unlocks a locked Surface.";

static PyObject* sdl_surface_mustlock(PyObject* self, PyObject* args);
static char sdl_surface_mustlock__doc__[] =
	"mustlock() -> bool\n"
	"This function determines whether a Surface must be locked\n"
	"in order to access its pixel data.";

static PyObject* sdl_surface_get_clip(PyObject* self, PyObject* args);
static char sdl_surface_get_clip__doc__[] =
	"get_clip() -> (min_x, min_y, max_x, max_y)\n"
	"This function returns a tuple containing the clipping regions\n"
	"of a Surface.";

static PyObject* sdl_surface_update_rect(PyObject* self, PyObject* args);
static char sdl_surface_update_rect__doc__[] =
	"update_rect((x, y, w, h)) -> None\n"
	"This function updates the rectangle specified.\n"
	"If all elements of the rectangle are zero, the entire Surface is updated.";

static PyObject* sdl_surface_update_rects(PyObject* self, PyObject* args);
static char sdl_surface_update_rects__doc__[] =
	"update_rects([(rect), (rect), ...]) -> None\n"
	"This function makes sure the areas represented by its argument rectangles\n"
	"are updated on the surface object.";

static PyObject* sdl_surface_get_masks(PyObject* self, PyObject* args);
static char sdl_surface_get_masks__doc__[] =
	"get_masks() -> (rmask, gmask, bmask, amask)\n"
	"This function returns the color masks for the Surface in RGBA format.";

static PyObject* sdl_surface_get_shifts(PyObject* self, PyObject* args);
static char sdl_surface_get_shifts__doc__[] =
	"get_shifts() -> (rshift, gshift, bshift, ashift)\n"
	"This function returns the bit shift information for the Surface.";

static PyObject* sdl_surface_get_losses(PyObject* self, PyObject* args);
static char sdl_surface_get_losses__doc__[] =
	"get_losses() -> (rloss, gloss, bloss, aloss)\n"
	"This function returns the amount of data lost\n"
	"for each RGBA component in bits.";
		
static PyObject* sdl_surface_get_alpha(PyObject* self, PyObject* args);
static char sdl_surface_get_alpha__doc__[] =
	"get_alpha() -> int\n"
	"This function returns the opacity information for a Surface.\n";

static PyObject* sdl_surface_get_colorkey(PyObject* self, PyObject* args);
static char sdl_surface_get_colorkey__doc__[] =
	"get_colorkey() -> int\n"
	"This function returns the color key information for a Surface.";

static PyObject* sdl_surface_get_info(PyObject* self, PyObject* args);
static char sdl_surface_get_info__doc__[] =
	"get_info() -> int\n"
	"Returns a bitmask indicating the state of the surface.\n"
	"This can be tested against the surface creation routine masks\n"
	"in order to determine what, if any, were used.";

static PyObject* sdl_surface_get_depth(PyObject* self, PyObject* args);
static char sdl_surface_get_depth__doc__[] =
	"get_depth() -> int\n"
	"Returns the color depth of the surface in bytes.";

static PyObject* sdl_surface_get_depth_bits(PyObject* self, PyObject* args);
static char sdl_surface_get_depth_bits__doc__[] =
	"get_depth_bits() -> int\n"
	"Returns the color depth of the surface in bits.";

static PyObject* sdl_surface_get_palette(PyObject* self, PyObject* args);
static char sdl_surface_get_palette__doc__[] =
	"get_palette() -> [(r, g, b), ...]\n"
	"This function returns the palette for a Surface as a list of colors.";

static PyObject* sdl_surface_pal_get_at(PyObject* self, PyObject* args);
static char sdl_surface_pal_get_at__doc__[] =
	"pal_get_at(index) -> (r, g, b)\n"
	"The function returns the color at index.";

static PyObject* sdl_surface_set_palette(PyObject* self, PyObject* args);
static char sdl_surface_set_palette__doc__[] =
	"set_palette([(r, g, b), ...]) -> None\n"
	"This function sets the palette for a Surface. The palette is not\n"
	"guranteed to be set exactly as requested, so inquery may be necessary.";

static PyObject* sdl_surface_pal_set_at(PyObject* self, PyObject* args);
static char sdl_surface_pal_set_at__doc__[] =
	"pal_set_at(index, (r, g, b)) -> None\n"
	"This function sets the palette entry at index to color.\n"
	"The entry is not guranteed to be set exactly as requested.";

static PyObject* sdl_surface_fill_rect(PyObject* self, PyObject* args);
static char sdl_surface_fill_rect__doc__[] =
	"fill_rect((x, y, w, h), color)) -> int\n"
	"This function fills the specified rectangle with the specified color.";

static PyObject* sdl_surface_flip(PyObject* self, PyObject* args);
static char sdl_surface_flip__doc__[] =
	"flip() -> int\n"
	"This function swaps buffers when using double buffering.";

static PyObject* sdl_surface_set_colorkey(PyObject* self, PyObject* args);
static char sdl_surface_set_colorkey__doc__[] =
	"set_colorkey(flags = 0, key = 0) -> int\n"
	"This function sets the color key for the Surface, or clears it\n"
	"if either no arguments are passed, or a flag of 0 is passed.\n";

static PyObject* sdl_surface_set_alpha(PyObject* self, PyObject* args);
static char sdl_surface_set_alpha__doc__[] =
	"set_alpha(flags = 0, alpha = 0) -> int\n"
	"This function sets the Surface opacity. If the flags argument is\n"
	"0, then the alpha channel is disabled.";

static PyObject* sdl_surface_set_clip(PyObject* self, PyObject* args);
static char sdl_surface_set_clip__doc__[] =
	"set_clip(min_x, min_y, max_x, max_y) -> None\n"
	"This function sets the clipping rectangle for the Surface.\n";

static PyObject* sdl_surface_convert(PyObject* self, PyObject* args);
static char sdl_surface_convert__doc__[] =
	"convert(src_surface, flags) -> Surface\n"
	"Return a copy of the calling surface that uses the format of the\n"
	"Surface argument.";

static PyObject* sdl_surface_blit(PyObject* self, PyObject* args);
static char sdl_surface_blit__doc__[] =
	"blit(src, (sx, sy, sw, sh), (dx, dy, dw, dh)) -> int\n"
	"Copies the section from src to the Surface.\n";

static PyObject* sdl_surface_convert_display(PyObject* self, PyObject* args);
static char sdl_surface_convert_display__doc__[] =
	"convert_display() -> Surface\n"
	"This function converts the given surface to the format of\n"
	"the display Surface.";

static PyObject* sdl_surface_save_bmp(PyObject* self, PyObject* args);
static char sdl_surface_save_bmp__doc__[] =
	"save_bmp(file or file object) -> int\n"
	"This function saves the Surface as a BMP file.";

/* font related prototypes and __doc__ strings */

static PyObject* sdl_font_NEW(TTF_Font* font);
static void sdl_font_dealloc(PyObject* self);
static PyObject* sdl_font_getattr(PyObject* self, char* attrname);

static PyObject* sdl_font_get_height(PyObject* self, PyObject* args);
static char sdl_font_get_height__doc__[] =
	"get_height() -> int\n"
	"Returns the general height of a glyph.";

static PyObject* sdl_font_get_descent(PyObject* self, PyObject* args);
static char sdl_font_get_descent__doc__[] =
	"get_descent() -> int\n"
	"Returns the offset from the baselines to the bottom of the font.";

static PyObject* sdl_font_get_skip(PyObject* self, PyObject* args);
static char sdl_font_get_skip__doc__[] =
	"get_skip() -> int\n"
	"Returns the recommended spacing between lines of text, for this font.";

static PyObject* sdl_font_get_style(PyObject* self, PyObject* args);
static char sdl_font_get_style__doc__[] =
	"get_style() -> int\n"
	"Returns the current font style. Supported styles are:\n"
	"TTF_STYLE_NORMAL\n"
	"TTF_STYLE_BOLD\n"
	"TTF_STYLE_ITALIC\n"
	"TTF_STYLE_UNDERLINE";

static PyObject* sdl_font_set_style(PyObject* self, PyObject* args);
static char sdl_font_set_style__doc__[] =
	"set_style(style) -> None\n"
	"Sets the style for the font. Supported styles are:\n"
	"TTF_STYLE_NORMAL\n"
	"TTF_STYLE_BOLD\n"
	"TTF_STYLE_ITALIC\n"
	"TTF_STYLE_UNDERLINE";

static PyObject* sdl_font_get_text_size(PyObject* self, PyObject* args);
static char sdl_font_get_text_size__doc__[] =
	"get_text_size(text) -> (x, y)\n"
	"Returns the size of the given text rendered in the font.";

static PyObject* sdl_font_get_utf8_size(PyObject* self, PyObject* args);
static char sdl_font_get_utf8_size__doc__[] =
	"get_utf8_size(text) -> (x, y)\n"
	"Return the size of the given text rendered in the font.";

/* Internal font functions */

static PyObject* sdl_font_get_size_i(PyObject* self, PyObject* args, int mode);

static PyObject* sdl_font_render_i(PyObject* self, PyObject* args, int mode);

/* render functions */

static PyObject* sdl_font_render(PyObject* self, PyObject* args);
static char sdl_font_render__doc__[] =
	"render(text, fgcolor (r, g, b), bgcolor (r, g, b)) -> Surface\n"
	"Returns a Surface containing text drawn using the specified colors.";

static PyObject* sdl_font_render_blended(PyObject* self, PyObject* args);
static char sdl_font_render_blended__doc__[] =
	"render_blended(text, fgcolor (r, g, b)) -> Surface\n"
	"Returns a Surface containing alpha blended text drawn using the\n"
	"specified foreground color.";

static PyObject* sdl_font_render_solid(PyObject* self, PyObject* args);
static char sdl_font_render_solid__doc__[] =
	"render_solid(text, fgcolor (r, g, b)) -> Surface\n"
	"Returns an 8-bit surface with the text drawn upon it using fast rendering.";

static PyObject* sdl_font_render_utf8(PyObject* self, PyObject* args);
static char sdl_font_render_utf8__doc__[] =
	"render_utf8(text, fgcolor (r, g, b), bgcolor (r, g, b)) -> Surface\n"
	"Returns a Surface containing text drawn using the specified colors.\n";

static PyObject* sdl_font_render_utf8_blended(PyObject* self, PyObject* args);
static char sdl_font_render_utf8_blended__doc__[] =
	"render_utf8_blended(text, fgcolor (r, g, b)) ->  Surface\n"
	"Returns a Surface containg alpha blended text draw using the specified\n"
	"foreground color.";

static PyObject* sdl_font_render_utf8_solid(PyObject* self, PyObject* args);
static char sdl_font_render_utf8_solid__doc__[] =
	"render_utf8_solid(text, fgcolor (r, g, b)) -> Surface\n"
	"Returns an 8-bit surface with the text drawn upon it using fast rendering.";

/*
 *  Unicode support will be useless until Python 1.6 
 * I'll add it then.
*/

/* sound related prototypes and __doc__ strings */

static void sdl_audiodev_dealloc(PyObject* self);
static PyObject* sdl_audiodev_getattr(PyObject* self, char* attrname);

static PyObject* sdl_audiodev_play(PyObject* self, PyObject* args);
static char sdl_audiodev_play__doc__[] =
	"play(channel, sound, loops = 0, ticks = -1) -> int\n"
	"Plays Sound on the specified channel for loops times, and\n"
	"ticks milliseconds."; 

static PyObject* sdl_audiodev_play_music(PyObject* self, PyObject* args);
static char sdl_audiodev_play_music__doc__[] =
	"play_music(music, loops = 0) -> int\n"
	"Plays Music loops times.";

static PyObject* sdl_audiodev_alloc_channels(PyObject* self, PyObject* args);
static char sdl_audiodev_alloc_channels__doc__[] =
	"alloc_channels(num_channels) -> int\n"
	"Changes the number of channels managed by the audio system.\n"
	"If decreasing the number of channels, the upper channels are stopped.\n"
	"The number of channels is returned, or -1 on error.";

static PyObject* sdl_audiodev_set_volume(PyObject* self, PyObject* args);
static char sdl_audiodev_set_volume__doc__[] =
	"set_volume(channel, volume) -> None\n"
	"Sets the volume for the specified channel (use -1 for all) to volume.";

static PyObject* sdl_audiodev_get_volume(PyObject* self, PyObject* args);
static char sdl_audiodev_get_volume__doc__[] =
	"get_volume(channel) -> int\n"
	"Returns the volume of the channel.";

static PyObject* sdl_audiodev_set_music_volume(PyObject* self, PyObject* args);
static char sdl_audiodev_set_music_volume__doc__[] =
	"set_music_volume(volume) -> None\n"
	"Sets the volume for the music channel to volume.";

static PyObject* sdl_audiodev_get_music_volume(PyObject* self, PyObject* args);
static char sdl_audiodev_get_music_volume__doc__[] =
	"get_music_volume() -> int\n"
	"Returns the volume of the music channel.";

static PyObject* sdl_audiodev_fade_in(PyObject* self, PyObject* args);
static char sdl_audiodev_fade_in__doc__[] =
	"fade_in(channel, Sound, ms, loops = 0, ticks - 1) -> int\n"
	"Fades in the Sound over ms milliseconds, and optionally looping for loops\n"
	"iterations, and playing for ticks milliseconds.";

static PyObject* sdl_audiodev_fade_in_music(PyObject* self, PyObject* args);
static char sdl_audiodev_fade_in_music__doc__[] =
	"fade_in_music(Music, ms, loops = 0) -> int\n"
	"Fades in the Music over ms millisecons, and optionally loop for loops\n"
	"iterations.";

static PyObject* sdl_audiodev_fade_out(PyObject* self, PyObject* args);
static char sdl_audiodev_fade_out__doc__[] =
	"fade_out(channel, ms) -> int\n"
	"Fades out channel over ms milliseconds.";

static PyObject* sdl_audiodev_fade_out_music(PyObject* self, PyObject* args);
static char sdl_audiodev_fade_out_music__doc__[] =
	"fade_out_music(ms) -> int\n"
	"Fades out the music over ms milliseconds.";

static PyObject* sdl_audiodev_halt(PyObject* self, PyObject* args);
static char sdl_audiodev_halt__doc__[] =
	"halt(channel) -> int\n"
	"Halts playing of the specified channel.";

static PyObject* sdl_audiodev_halt_music(PyObject* self, PyObject* args);
static char sdl_audiodev_halt_music__doc__[] =
	"halt_music() -> int\n"
	"Halts playing of the current music track.";

static PyObject* sdl_audiodev_expire(PyObject* self, PyObject* args);
static char sdl_audiodev_expire__doc__[] =
	"expire(channel, ticks) -> int\n"
	"Has channel stop playing after ticks milliseconds.";

static PyObject* sdl_audiodev_pause(PyObject* self, PyObject* args);
static char sdl_audiodev_pause__doc__[] =
	"pause(channel) -> None\n"
	"Pauses the specified channel.";

static PyObject* sdl_audiodev_pause_music(PyObject* self, PyObject* args);
static char sdl_audiodev_pause_music__doc__[] =
	"pause_music() -> None\n"
	"Pauses the music channel.";

static PyObject* sdl_audiodev_resume(PyObject* self, PyObject* args);
static char sdl_audiodev_resume__doc__[] =
	"resume(channel) -> None\n"
	"Resumes the specified channel.";

static PyObject* sdl_audiodev_resume_music(PyObject* self, PyObject* args);
static char sdl_audiodev_resume_music__doc__[] =
	"resume_music() -> None\n"
	"Resumes the music channel.";

static PyObject* sdl_audiodev_rewind_music(PyObject* self, PyObject* args);
static char sdl_audiodev_rewind_music__doc__[] =
	"rewind_music() -> None\n"
	"Rewinds the music track.";

static PyObject* sdl_audiodev_is_paused(PyObject* self, PyObject* args);
static char sdl_audiodev_is_paused__doc__[] =
	"is_paused(channel) -> int\n"
	"Returns indicating whether the specified channel is paused or not.";

static PyObject* sdl_audiodev_is_music_paused(PyObject* self, PyObject* args);
static char sdl_audiodev_is_music_paused__doc__[] =
	"is_music_paused() -> int\n"
	"Returns indicating whether the music channel is paused or not.";

static PyObject* sdl_audiodev_is_playing(PyObject* self, PyObject* args);
static char sdl_audiodev_is_playing__doc__[] =
	"is_playing(channel) -> int\n"
	"Returns indicating whether the specified channel is playing or not.";

static PyObject* sdl_audiodev_is_music_playing(PyObject* self, PyObject* args);
static char sdl_audiodev_is_music_playing__doc__[] =
	"is_music_playing() -> int\n"
	"Returns indicating whether the music channel is playing or not.";

static PyObject* sdl_audiodev_fading(PyObject* self, PyObject* args);
static char sdl_audiodev_fading__doc__[] =
	"fading(channel) -> int\n"
	"Returns the current fade state of the specified channel.\n"
	"MIX_NO_FADING\n"
	"MIX_FADING_OUT\n"
	"MIX_FADING_IN";

static PyObject* sdl_audiodev_fading_music(PyObject* self, PyObject* args);
static char sdl_audiodev_fading_music__doc__[] =
	"fading_music() -> int\n"
	"Returns the current fade stated of the music channel.";

static PyObject* sdl_audiodev_get_freq(PyObject* self, PyObject* args);
static char sdl_audiodev_get_freq__doc__[] =
	"get_freq() -> int\n"
	"Returns the actual frequency the audio device is currently using.";

static PyObject* sdl_audiodev_get_format(PyObject* self, PyObject* args);
static char sdl_audiodev_get_format__doc__[] =
	"get_format() -> int\n"
	"Returns the actual format used by the audio device.";

static PyObject* sdl_audiodev_get_channels(PyObject* self, PyObject* args);
static char sdl_audiodev_get_channels__doc__[] =
	"get_channels() -> int\n"
	"Returns the number of channels actually being used.";

/* Sound object related */

static void sdl_sound_dealloc(PyObject* self);
static PyObject* sdl_sound_getattr(PyObject* self, char* attrname);

static PyObject* sdl_sound_get_len(PyObject* self, PyObject* args);
static char sdl_sound_get_len__doc__[] =
	"get_len() -> int\n"
	"Returns the length of the audio buffer in bytes";

static PyObject* sdl_sound_set_volume(PyObject* self, PyObject* args);
static char sdl_sound_set_volume__doc__[] =
	"set_volume(volume) -> None\n"
	"Sets the volume for the audio buffer.";

static PyObject* sdl_sound_get_volume(PyObject* self, PyObject* args);
static char sdl_sound_get_volume__doc__[] =
	"get_volume() -> int\n"
	"Returns the volume of the audio buffer.";

/* Music object related */

static PyObject* sdl_music_NEW(Mix_Music* m_music_ref);
static void sdl_music_dealloc(PyObject* self);
static PyObject* sdl_music_getattr(PyObject* self, char* attrname);

static PyObject* sdl_audio_open(PyObject* self, PyObject* args);
static char sdl_audio_open__doc__[] =
	"audio_open(frequency, format, channels, samples = 4096) -> Audio\n"
	"Sets the audio device to play at frequency in format with an audio buffer\n"
	"of size samples.";

static PyObject* sdl_sound_load(PyObject* self, PyObject* args);
static char sdl_sound_load__doc__[] =
	"sound_load(file or file object) -> Sound\n"
	"Creates a Sound from a WAV file or a file object whose current\n"
	"position marks the start of a WAV.";

static PyObject* sdl_music_load(PyObject* self, PyObject* args);
static char sdl_music_load__doc__[] =
	"music_load(file) -> Music\n"
	"Creates a Music from a .mod, .s3m, .it, .mp3, or .xm file";

/* CD related prototypes and __doc__ strings */


/* constructors, destructors, and sequence functions */

static PyObject* sdl_cd_NEW(SDL_CD* cdrom);
static void sdl_cd_dealloc(PyObject* self);
static PyObject* sdl_cd_getattr(PyObject* self, char* attrname);
static int sdl_cd_seq_len(PyObject* self);
static PyObject* sdl_cd_seq_get(PyObject* self, int index);
static PyObject* sdl_cd_seq_get_slice(PyObject* self, int start, int end);

/* CD methods and CD-ROM related functions */

static PyObject* sdl_cdrom_open(PyObject* self, PyObject* args);
static char sdl_cdrom_open__doc__[] =
	"cdrom_open(id) -> CD\n"
	"This function retrieves a CD for the given id.";

static PyObject* sdl_cdrom_get_count(PyObject* self, PyObject* args);
static char sdl_cdrom_get_count__doc__[] =
	"cdrom_get_count() -> int\n"
	"This function returns the number of CD-ROM drives installed.";

static PyObject* sdl_cdrom_get_name(PyObject* self, PyObject* args);
static char sdl_cdrom_get_name__doc__[] =
	"cdrom_get_name(id) -> string\n"
	"This function returns the name of the CD-ROM drive whose id is specified";

static PyObject* sdl_cd_play_tracks(PyObject* self, PyObject* args);
static char sdl_cd_play_tracks__doc__[] =
	"play_tracks(start_track, start_frame, ntracks, nframes) -> int\n"
	"Start playing from start_track, for ntracks and nframes.\n"
	"If ntracks and nframes are 0, it will play until the end of the CD";

static PyObject* sdl_cd_play(PyObject* self, PyObject* args);
static char sdl_cd_play__doc__[] =
	"play(start_frame, nframes) -> int\n"
	"Start playing from start_frame for nframes.";

static PyObject* sdl_cd_pause(PyObject* self, PyObject* args);
static char sdl_cd_pause__doc__[] =
	"pause() -> int\n"
	"Pause the currently playing CD.";

static PyObject* sdl_cd_resume(PyObject* self, PyObject* args);
static char sdl_cd_resume__doc__[] =
	"resume() -> int\n"
	"Resume the currently paused CD.";

static PyObject* sdl_cd_stop(PyObject* self, PyObject* args);
static char sdl_cd_stop__doc__[] =
	"stop() -> int\n"
	"Stop the CD.";

static PyObject* sdl_cd_eject(PyObject* self, PyObject* args);
static char sdl_cd_eject__doc__[] =
	"eject() -> int\n"
	"Eject the CD.";

static PyObject* sdl_cd_get_status(PyObject* self, PyObject* args);
static char sdl_cd_get_status__doc__[] =
	"get_status() -> int\n"
	"Returns the status of the CD object.";

static PyObject* sdl_cd_get_cur_track(PyObject* self, PyObject* args);
static char sdl_cd_get_cur_track__doc__[] =
	"get_cur_track() -> int\n"
	"Returns the current track's position, or -1.";

static PyObject* sdl_cd_get_cur_frame(PyObject* self, PyObject* args);
static char sdl_cd_get_cur_frame__doc__[] =
	"get_cur_frame() -> int\n"
	"Returns the current frame position, or -1.";

static PyObject* sdl_cd_has_cd(PyObject* self, PyObject* args);
static char sdl_cd_has_cd__doc__[] =
	"has_cd() -> int\n"
	"Returns 0 if there is no CD in the drive, or 1 otherwise.";

/* Event related prototypes and __doc__ strings */

static PyObject* sdl_event_NEW(SDL_Event* event);
static PyObject* sdl_event_new(PyObject* self, PyObject* args);
static char sdl_event_new__doc__[] =
	"event_new(type) -> Event\n"
	"This creates a new Event of the specified type.";

static void sdl_event_dealloc(PyObject* self);
static PyObject* sdl_event_getattr(PyObject* self, char* attrname);

static PyObject* sdl_event_get_type(PyObject* self, PyObject* args);
static char sdl_event_get_type__doc__[] =
	"get_type() -> int\n"
	"Returns the type of the Event.\n"
	"Supported types:\n"
	"ACTIVEEVENT - application lost/gained focus\n"
	"KEYDOWN - keyboard key pressed\n"
	"KEYUP - keyboard key released\n"
	"MOUSEMOTION - mouse moved\n"
	"MOUSEBUTTONDOWN - mouse button pressed\n"
	"MOUSEBUTTONUP - mouse button released\n"
	"JOYAXISMOTION - joystick axis has moved\n"
	"JOYBALLMOTION - joystick trackball has moved\n"
	"JOYHATMOTION - joystick hat has moved\n"
	"JOYBUTTONDOWN - joystick button pressed\n"
	"JOYBUTTONUP - joystick button released\n"
	"QUIT - quit requested\n";

static PyObject* sdl_event_active_get_gain(PyObject* self, PyObject* args);
static char sdl_event_active_get_gain__doc__[] =
	"get_gain() -> int\n"
	"Tells if the application gained or lost focus.";

static PyObject* sdl_event_active_set_gain(PyObject* self, PyObject* args);
static char sdl_event_active_set_gain__doc__[] =
	"set_gain(gain) -> None\n"
	"Sets whether the application gained or lost focus.";

static PyObject* sdl_event_active_get_state(PyObject* self, PyObject* args);
static char sdl_event_active_get_state__doc__[] =
	"get_state() -> int\n"
	"Returns the state of the application.";

static PyObject* sdl_event_active_set_state(PyObject* self, PyObject* args);
static char sdl_event_active_set_state__doc__[] =
	"set_state(state) -> None\n"
	"Sets the state of the application.";

static PyObject* sdl_event_key_get_state(PyObject* self, PyObject* args);
static char sdl_event_key_get_state__doc__[] =
	"get_state() -> int\n"
	"Returns the state of the key.";

static PyObject* sdl_event_key_set_state(PyObject* self, PyObject* args);
static char sdl_event_key_set_state__doc__[] =
	"set_state(state) -> None\n"
	"Sets the state of the key.";

static PyObject* sdl_event_key_get_sym(PyObject* self, PyObject* args);
static char sdl_event_key_get_sym__doc__[] =
	"get_sym() -> int\n"
	"Returns the keysym for the key.";

static PyObject* sdl_event_key_set_sym(PyObject* self, PyObject* args);
static char sdl_event_key_set_sym__doc__[] =
	"set_sym(sym) -> None\n"
	"Sets the keysym for the key.";

static PyObject* sdl_event_key_get_mod(PyObject* self, PyObject* args);
static char sdl_event_key_get_mod__doc__[] =
	"get_mod() -> int\n"
	"Returns the key modifiers.";

static PyObject* sdl_event_key_set_mod(PyObject* self, PyObject* args);
static char sdl_event_key_set_mod__doc__[] =
	"set_mod(mod) -> None\n"
	"Sets the key modifiers.";

static PyObject* sdl_event_mouse_get_coords(PyObject* self, PyObject* args);
static char sdl_event_mouse_get_coords__doc__[] =
	"get_coords() -> (x, y, x_rel, y_rel)\n"
	"Returns the coordinates of the mouse, and the relative change.";

static PyObject* sdl_event_mouse_set_coords(PyObject* self, PyObject* args);
static char sdl_event_mouse_set_coords__doc__[] =
	"set_coords((x, y, x_rel, y_rel)) -> None\n"
	"Sets the coordinates of the mouse, and the relative changed.";

static PyObject* sdl_event_mouse_get_state(PyObject* self, PyObject* args);
static char sdl_event_mouse_get_state__doc__[] =
	"get_state() -> int\n"
	"Returns the state of the mouse buttons.\n";

static PyObject* sdl_event_mouse_set_state(PyObject* self, PyObject* args);
static char sdl_event_mouse_set_state__doc__[] =
	"set_state(state) -> None\n"
	"Sets the state of the mouse button.";

static PyObject* sdl_event_button_get_state(PyObject* self, PyObject* args);
static char sdl_event_button_get_state__doc__[] =
	"get_state() -> int\n"
	"Tells if the mouse button was pressed or released."
	"PRESSED - button was pressed\n"
	"RELEASED - button was released\n";
	
static PyObject* sdl_event_button_set_state(PyObject* self, PyObject* args);
static char sdl_event_button_set_state__doc__[] =
	"set_state(state) -> None\n"
	"Sets the state of the mouse button to pressed or released.";

static PyObject* sdl_event_button_get_button(PyObject* self, PyObject* args);
static char sdl_event_button_get_button__doc__[] =
	"get_button() -> int\n"
	"Returns the button number.";

static PyObject* sdl_event_button_set_button(PyObject* self, PyObject* args);
static char sdl_event_button_set_button__doc__[] =
	"set_button(button) -> None\n"
	"Sets the button number for the event.";

static PyObject* sdl_event_button_get_coords(PyObject* self, PyObject* args);
static char sdl_event_button_get_coords__doc__[] =
	"get_coords() -> (x, y)\n"
	"Returns the x and y coordinates of the mouse.";

static PyObject* sdl_event_button_set_coords(PyObject* self, PyObject* args);
static char sdl_event_button_set_coords__doc__[] =
	"set_coords((x,y)) -> None\n"
	"Sets the x and y coordinates of the mouse, for the event.";

static PyObject* sdl_event_joy_axis_get_ids(PyObject* self, PyObject* args);
static char sdl_event_joy_axis_get_ids__doc__[] =
	"get_ids() -> (joystick_id, axis_id)\n"
	"Returns information about which joystick and which axis the event is for.";

static PyObject* sdl_event_joy_axis_set_ids(PyObject* self, PyObject* args);
static char sdl_event_joy_axis_set_ids__doc__[] =
	"set_ids((joystick_id, axis_id)) -> None\n"
	"Sets the joystick and axis ids for the event.";

static PyObject* sdl_event_joy_axis_get_state(PyObject* self, PyObject* args);
static char sdl_event_joy_axis_get_state__doc__[] =
	"get_state() -> int\n"
	"Returns the state of the axis from -32768 to 32767.";

static PyObject* sdl_event_joy_axis_set_state(PyObject* self, PyObject* args);
static char sdl_event_joy_axis_set_state__doc__[] =
	"set_state(state) -> None\n"
	"Sets the state of the axis for the event.";

static PyObject* sdl_event_joy_ball_get_ids(PyObject* self, PyObject* args);
static char sdl_event_joy_ball_get_ids__doc__[] =
	"get_ids() -> (joystick_id, trackball_id)\n"
	"Returns the joystick and trackball ids for the event.";

static PyObject* sdl_event_joy_ball_set_ids(PyObject* self, PyObject* args);
static char sdl_event_joy_ball_set_ids__doc__[] =
	"set_ids((joystick_id, trackball_id) -> None\n"
	"Sets the joystick and trackball ids for the event.";

static PyObject* sdl_event_joy_ball_get_coords(PyObject* self, PyObject* args);
static char sdl_event_joy_ball_get_coords__doc__[] =
	"get_coords() -> (x_rel, y_rel)\n"
	"Returns the relative change in the x and y directions.";	

static PyObject* sdl_event_joy_ball_set_coords(PyObject* self, PyObject* args);
static char sdl_event_joy_ball_set_coords__doc__[] =
	"set_coords((x_rel, y_rel)) -> None\n"
	"Sets the relative change in the x and y directions.";

static PyObject* sdl_event_joy_hat_get_ids(PyObject* self, PyObject* args);
static char sdl_event_joy_hat_get_ids__doc__[] =
	"get_ids() -> (joystick_id, hat_id)\n"
	"Returns the ids of the joystick and hat.";

static PyObject* sdl_event_joy_hat_set_ids(PyObject* self, PyObject* args);
static char sdl_event_joy_hat_set_ids__doc__[] =
	"set_ids((joystick_id, hat_id)) -> None\n"
	"Sets the ids of the joystick and hat.";

static PyObject* sdl_event_joy_hat_get_pos(PyObject* self, PyObject* args);
static char sdl_event_joy_hat_get_pos__doc__[] =
	"get_pos() -> int\n"
	"Returns the hat POV.\n"
	"HAT_LEFTUP   HAT_UP       HAT_RIGHTUP\n"
	"HAT_LEFT     HAT_CENTERED HAT_RIGHT \n"
	"HAT_LEFTDOWN HAT_DOWN     HAT_RIGHTDOWN\n";

static PyObject* sdl_event_joy_hat_set_pos(PyObject* self, PyObject* args);
static char sdl_event_joy_hat_set_pos__doc__[] =
	"set_pos(position) -> None\n"
	"Sets the hat position.";

static PyObject* sdl_event_jbutton_get_ids(PyObject* self, PyObject* args);
static char sdl_event_jbutton_get_ids__doc__[] =
	"get_ids() -> (joystick_id, button_id)\n"
	"Returns the joystick and button ids.";

static PyObject* sdl_event_jbutton_set_ids(PyObject* self, PyObject* args);
static char sdl_event_jbutton_set_ids__doc__[] =
	"set_ids((joystick_id, button_id)) -> None\n"
	"Sets the joystick and button ids.";

static PyObject* sdl_event_jbutton_get_state(PyObject* self, PyObject* args);
static char sdl_event_jbutton_get_state__doc__[] =
	"get_state() -> int\n"
	"Returns 1 if the button is being pushed, or 0 if not.";

static PyObject* sdl_event_jbutton_set_state(PyObject* self, PyObject* args);
static char sdl_event_jbutton_set_state__doc__[] =
	"set_state(state) -> None\n"
	"Sets the state of the joystick button.";

static PyObject* sdl_event_resize_get_width(PyObject* self, PyObject* args);
static char sdl_event_resize_get_width__doc__[] =
	"get_width() -> int\n"
	"Returns the new width of the display.";

static PyObject* sdl_event_resize_get_height(PyObject* self, PyObject* args);
static char sdl_event_resize_get_height__doc__[] =
	"get_height() -> int\n"
	"Returns the new height of the display.";

static PyObject* sdl_events_pump(PyObject* self, PyObject* args);
static char sdl_events_pump__doc__[] =
	"events_pump() -> None\n"
	"Gathers events from input devices and updates the event queue.\n";

/* This is an internal function */
static PyObject* sdl_events_peep(int count, Uint32 mask,
	 SDL_eventaction action);

static PyObject* sdl_events_peek(PyObject* self, PyObject* args);
static char sdl_events_peek__doc__[] =
	"events_peek(type, count) -> (Event, ...) or -1\n"
	"Gathers up to count messages from the queue matching type, but does not\n"
	"remove them.";

static PyObject* sdl_events_get(PyObject* self, PyObject* args);
static char sdl_events_get__doc__[] =
	"events_get(type, count) -> (Event, ...) or -1\n"
	"Gathers and removes up to count messages from the queue matching type.";

static PyObject* sdl_events_add(PyObject* self, PyObject* args);
static char sdl_events_add__doc__[] =
	"events_add(event) -> 0 or -1\n"
	"Adds the event to the back of the event queue.";

static PyObject* sdl_events_poll(PyObject* self, PyObject* args);
static char sdl_events_poll__doc__[] =
	"events_poll() -> Event or -1\n"
	"Returns the next pending Event or -1.";

static PyObject* sdl_events_wait(PyObject* self, PyObject* args);
static char sdl_events_wait__doc__[] =
	"events_wait() -> Event or -1\n"
	"Waits for the next event and then returns it.";

static PyObject* sdl_events_state(PyObject* self, PyObject* args);
static char sdl_events_state__doc__[] =
	"events_state(event_type, state) -> int\n"
	"Allows the caller to set the state of event processing, or to query\n"
	"the current state of a given event type.";

static PyObject* sdl_events_key_repeat(PyObject* self, PyObject* args);
static char sdl_events_key_repeat__doc__[] =
	"events_key_repeat(delay, interval) -> None\n"
	"Sets the keyboard delay and interval values. If delay is zero, then\n"
	"keyboard repeat is turned off.";

static PyObject* sdl_events_get_key_state(PyObject* self, PyObject* args);
static char sdl_events_get_key_state__doc__[] =
	"events_get_key_state() -> (state,...)\n"
	"Returns the state of the keys.";

static PyObject* sdl_events_get_key_name(PyObject* self, PyObject* args);
static char sdl_events_get_key_name__doc__[] =
	"events_get_key_name(key) -> string\n"
	"Returns the name of the given key.";

static PyObject* sdl_events_get_mod(PyObject* self, PyObject* args);
static char sdl_events_get_mod__doc__[] =
	"events_get_mod() -> int\n"
	"Returns the current modifier state.\n"
	"Modifiers are:\n"
	"KMOD_NONE - no modifiers pressed\n"
	"KMOD_LSHIFT - left shift pressed\n"
	"KMOD_RSHIFT - right shift pressed\n"
	"KMOD_LCTRL - left control pressed\n"
	"KMOD_RCTRL - right control pressed\n"
	"KMOD_CTRL - left or right control pressed\n"
	"KMOD_LALT - left alt pressed\n"
	"KMOD_RALT - right alt pressed\n"
	"KMOD_ALT - left or right alt pressed\n"
	"KMOD_LMETA - left meta pressed\n"
	"KMOD_RMETA - right meta pressed\n"
	"KMOD_META - left or right meta pressed\n"
	"KMOD_NUM - num lock pressed\n"
	"KMOD_CAPS - caps lock pressed\n"
	"KMOD_MODE - mode pressed\n";


/* Joystick related prototypes and __doc__ strings */

static PyObject* sdl_joy_NEW(SDL_Joystick* joy);
static void sdl_joy_dealloc(PyObject* self);
static PyObject* sdl_joy_getattr(PyObject* self, char* atrrname);


static PyObject* sdl_joy_get_id(PyObject* self, PyObject* args);
static char sdl_joy_get_id__doc__[] =
	"get_id() -> id\n"
	"Returns the id of the joystick object.";

static PyObject* sdl_joy_get_axes(PyObject* self, PyObject* args);
static char sdl_joy_get_axes__doc__[] =
	"get_axes() -> count\n"
	"Returns the number of axis controls.";

static PyObject* sdl_joy_get_balls(PyObject* self, PyObject* args);
static char sdl_joy_get_balls__doc__[] =
	"get_balls() -> count\n"
	"Returns the number of trackballs.";

static PyObject* sdl_joy_get_hats(PyObject* self, PyObject* args);
static char sdl_joy_get_hats__doc__[] =
	"get_hats() -> count\n"
	"Returns the number of POV hats.";

static PyObject* sdl_joy_get_buttons(PyObject* self, PyObject* args);
static char sdl_joy_get_buttons__doc__[] =
	"get_buttons() -> count\n"
	"Returns the number of buttons.";

static PyObject* sdl_joy_get_axis(PyObject* self, PyObject* args);
static char sdl_joy_get_axis__doc__[] =
	"get_axis(axis) -> state\n"
	"Returns the current state of an axis control on the joystick.\n"
	"The values range from -32768 to 32767.";

static PyObject* sdl_joy_get_hat(PyObject* self, PyObject* args);
static char sdl_joy_get_hat__doc__[] =
	"get_hat(pov_hat) -> state\n"
	"Returns the current state of a POV hat on the joystick.\n"
	"HAT_LEFTUP   HAT_UP       HAT_RIGHTUP\n"
	"HAT_LEFT     HAT_CENTERED HAT_RIGHT \n"
	"HAT_LEFTDOWN HAT_DOWN     HAT_RIGHTDOWN\n"; 

static PyObject* sdl_joy_get_button(PyObject* self, PyObject* args);
static char sdl_joy_get_button__doc__[] =
	"get_button(button) -> int\n"
	"Indicates whether the joystick button is down or not.";

static PyObject* sdl_joy_open(PyObject* self, PyObject* args);
static char sdl_joy_open__doc__[] =
	"joy_open(id) -> Joystick\n"
	"Opens the specified joystick, and returns an object for manipulating it.";

static PyObject* sdl_joy_get_count(PyObject* self, PyObject* args);
static char sdl_joy_get_count__doc__[] =
	"joy_get_count() -> int\n"
	"Returns the number of joysticks attached to the system.";

static PyObject* sdl_joy_get_name(PyObject* self, PyObject* args);
static char sdl_joy_get_name__doc__[] =
	"joy_get_name(id) -> string\n"
	"Returns the name of the joystick identified by id.";

static PyObject* sdl_joy_is_opened(PyObject* self, PyObject* args);
static char sdl_joy_is_opened__doc__[] =
	"joy_is_opened(id) -> int\n"
	"Returns whether the joystick identified by id has been opened or not.";

static PyObject* sdl_joy_update(PyObject* self, PyObject* args);
static char sdl_joy_update__doc__[] =
	"joy_update() -> None\n"
	"Updates the current state of open joysticks.";

static PyObject* sdl_joy_event_state(PyObject* self, PyObject* args);
static char sdl_joy_event_state__doc__[] =
	"joy_event_state(state) -> int\n"
	"Either queries the current state regarding the automatic generation of\n"
	"joystick events, or sets the state accordingly.";

/* Module structures */

static PyMethodDef sdl__builtins__[] =
{
	{ "init", sdl_init, 1, sdl_init__doc__ }, 
	{ "init_subsystem", sdl_init_subsystem, 1, sdl_init_subsystem__doc__ },
	{ "quit_subsystem", sdl_quit_subsystem, 1, sdl_quit_subsystem__doc__ },
	{ "quit", sdl_quit, 1, sdl_quit__doc__ },
	{ "get_app_state", sdl_get_app_state, 1, sdl_get_app_state__doc__ },
	{ "video_init", sdl_video_init, 1, sdl_video_init__doc__ },
	{ "video_quit", sdl_video_quit, 1, sdl_video_quit__doc__ },
	{ "video_driver_name", sdl_video_driver_name, 1, 
		sdl_video_driver_name__doc__ },
	{ "video_get_surface", sdl_video_get_surface, 1, 
		sdl_video_get_surface__doc__ },
	{ "video_set_mode", sdl_video_set_mode, 1,
		sdl_video_set_mode__doc__ },
	{ "video_mode_ok", sdl_video_mode_ok, 1, sdl_video_mode_ok__doc__ },
	{ "video_list_modes", sdl_video_list_modes, 1, sdl_video_list_modes__doc__ },
	{ "video_info", sdl_video_info, 1, sdl_video_info__doc__ },
	{ "video_set_gl", sdl_video_set_gl, 1, sdl_video_set_gl__doc__ },
	{ "video_get_gl", sdl_video_get_gl, 1, sdl_video_get_gl__doc__ },
	{ "video_swap_gl", sdl_video_swap_gl, 1, sdl_video_swap_gl__doc__ },
	{ "font_load", sdl_font_load, 1, sdl_font_load__doc__ },
	{ "image_load", sdl_image_load, 1, sdl_image_load__doc__ },
	{ "image_is", sdl_image_is, 1, sdl_image_is__doc__ },
	{ "image_load_type", sdl_image_load_type, 1, sdl_image_load_type__doc__ },
	{ "image_invert_alpha", sdl_image_invert_alpha, 1, 
		sdl_image_invert_alpha__doc__ },
	{ "get_error", sdl_get_error, 1, sdl_get_error__doc__ },
	{ "get_ticks", sdl_get_ticks, 1, sdl_get_ticks__doc__ },
	{ "delay", sdl_delay, 1, sdl_delay__doc__ },
	{ "cursor_show", sdl_cursor_show, 1, sdl_cursor_show__doc__ },
	{ "mouse_warp", sdl_mouse_warp, 1, sdl_mouse_warp__doc__ },
	{ "wm_grab_input", sdl_wm_grab_input, 1, sdl_wm_grab_input__doc__ },
	{ "wm_toggle_fullscreen", sdl_wm_toggle_fullscreen, 1,
		sdl_wm_toggle_fullscreen__doc__ },
	{ "wm_iconify", sdl_wm_iconify, 1, sdl_wm_iconify__doc__ },
	{ "wm_set_icon", sdl_wm_set_icon, 1, sdl_wm_set_icon__doc__ },
	{ "wm_get_caption", sdl_wm_get_caption, 1, sdl_wm_get_caption__doc__ },
	{ "wm_set_caption", sdl_wm_set_caption, 1, sdl_wm_set_caption__doc__ },
	{ "surface_new", sdl_surface_new, 1, sdl_surface_new__doc__ },
	{ "cdrom_get_count", sdl_cdrom_get_count, 1, sdl_cdrom_get_count__doc__ },
	{ "cdrom_get_name", sdl_cdrom_get_name, 1, sdl_cdrom_get_name__doc__ },
	{ "cdrom_open", sdl_cdrom_open, 1, sdl_cdrom_open__doc__ },
	{ "event_new", sdl_event_new, 1, sdl_event_new__doc__ },
	{ "events_pump", sdl_events_pump, 1, sdl_events_pump__doc__ },
	{ "events_poll", sdl_events_poll, 1, sdl_events_poll__doc__ },
	{ "events_wait", sdl_events_wait, 1, sdl_events_wait__doc__ },
	{ "events_peek", sdl_events_peek, 1, sdl_events_peek__doc__ },
	{ "events_get", sdl_events_get, 1, sdl_events_get__doc__ },
	{ "events_add", sdl_events_add, 1, sdl_events_add__doc__ },
	{ "events_state", sdl_events_state, 1, sdl_events_state__doc__ },
	{ "events_key_repeat", sdl_events_key_repeat, 1,
		sdl_events_key_repeat__doc__ },
	{ "events_get_key_state", sdl_events_get_key_state, 1,
		sdl_events_get_key_state__doc__ },
	{ "events_get_key_name", sdl_events_get_key_name, 1,
		sdl_events_get_key_name__doc__ },
	{ "events_get_mod", sdl_events_get_mod, 1, sdl_events_get_mod__doc__ },
	{ "joy_get_count", sdl_joy_get_count, 1, sdl_joy_get_count__doc__ },
	{ "joy_get_name", sdl_joy_get_name, 1, sdl_joy_get_name__doc__ },
	{ "joy_open", sdl_joy_open, 1, sdl_joy_open__doc__ },
	{ "joy_is_opened", sdl_joy_is_opened, 1, sdl_joy_is_opened__doc__ },
	{ "joy_update", sdl_joy_update, 1, sdl_joy_update__doc__ },
	{ "joy_event_state", sdl_joy_event_state, 1, sdl_joy_event_state__doc__ },
	{ "audio_open", sdl_audio_open, 1, sdl_audio_open__doc__ },
	{ "sound_load", sdl_sound_load, 1, sdl_sound_load__doc__ },
	{ "music_load", sdl_music_load, 1, sdl_music_load__doc__ },
	{ NULL, NULL }
};

static PySequenceMethods sdl_surface_as_sequence =
{
	sdl_surface_seq_len,
	0,
	0,
	sdl_surface_seq_get,
	sdl_surface_seq_get_slice,
	sdl_surface_seq_set,
	sdl_surface_seq_set_slice
};

static PySequenceMethods sdl_cd_as_sequence = 
{
	sdl_cd_seq_len,
	0,
	0,
	sdl_cd_seq_get,
	sdl_cd_seq_get_slice,
	0,
	0
};

static PyMethodDef sdl_surface__builtins__[] =
{
	{ "get_height", sdl_surface_get_height, 1, sdl_surface_get_height__doc__ },
	{ "get_width", sdl_surface_get_width, 1, sdl_surface_get_width__doc__ },
	{ "get_pitch", sdl_surface_get_pitch, 1, sdl_surface_get_pitch__doc__ },
	{ "map_rgb", sdl_surface_map_rgb, 1, sdl_surface_map_rgb__doc__ },
	{ "get_rgb", sdl_surface_get_rgb, 1, sdl_surface_get_rgb__doc__ },
	{ "lock", sdl_surface_lock, 1, sdl_surface_lock__doc__ },
	{ "unlock", sdl_surface_unlock, 1, sdl_surface_unlock__doc__ },
	{ "mustlock", sdl_surface_mustlock, 1, sdl_surface_mustlock__doc__ },
	{ "get_clip", sdl_surface_get_clip, 1, sdl_surface_get_clip__doc__ },
	{ "update_rect", sdl_surface_update_rect, 1,
		sdl_surface_update_rect__doc__ },
	{ "update_rects", sdl_surface_update_rects, 1, 
		sdl_surface_update_rects__doc__ },
	{ "get_masks", sdl_surface_get_masks, 1, sdl_surface_get_masks__doc__ },
	{ "get_shifts", sdl_surface_get_shifts, 1, sdl_surface_get_shifts__doc__ },
	{ "get_losses", sdl_surface_get_losses, 1, sdl_surface_get_losses__doc__ },
	{ "get_alpha", sdl_surface_get_alpha, 1, sdl_surface_get_alpha__doc__ },
	{ "get_colorkey", sdl_surface_get_colorkey, 1, 
		sdl_surface_get_colorkey__doc__ },
	{ "get_info", sdl_surface_get_info, 1,
		sdl_surface_get_info__doc__ },
	{ "get_depth", sdl_surface_get_depth, 1,
		sdl_surface_get_depth__doc__ },
	{ "get_depth_bits", sdl_surface_get_depth_bits, 1,
		sdl_surface_get_depth_bits__doc__ },
	{ "get_palette", sdl_surface_get_palette, 1, 
		sdl_surface_get_palette__doc__ },
	{ "pal_get_at", sdl_surface_pal_get_at, 1,
		sdl_surface_pal_get_at__doc__ },
	{ "set_palette", sdl_surface_set_palette, 1,
		sdl_surface_set_palette__doc__ },
	{ "pal_set_at", sdl_surface_pal_set_at, 1,
		sdl_surface_pal_set_at__doc__ },
	{ "fill_rect", sdl_surface_fill_rect, 1, sdl_surface_fill_rect__doc__ },
	{ "flip", sdl_surface_flip, 1, sdl_surface_flip__doc__ },
	{ "set_colorkey", sdl_surface_set_colorkey, 1,
		sdl_surface_set_colorkey__doc__ },
	{ "set_alpha", sdl_surface_set_alpha, 1, sdl_surface_set_alpha__doc__ },
	{ "set_clip", sdl_surface_set_clip, 1, sdl_surface_set_clip__doc__ },
	{ "convert", sdl_surface_convert, 1, sdl_surface_convert__doc__ },
	{ "convert_display", sdl_surface_convert_display, 1,
		sdl_surface_convert_display__doc__ },
	{ "blit", sdl_surface_blit, 1, sdl_surface_blit__doc__ },
	{ "save_bmp", sdl_surface_save_bmp, 1, sdl_surface_save_bmp__doc__ },
	{ "get_at", sdl_surface_get_at, 1, sdl_surface_get_at__doc__ },
	{ "set_at", sdl_surface_set_at, 1, sdl_surface_set_at__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_font__builtins__[] =
{
	{ "get_height", sdl_font_get_height, 1, sdl_font_get_height__doc__ },
	{ "render", sdl_font_render, 1, sdl_font_render__doc__ },
	{ "render_blended", sdl_font_render_blended, 1,
		sdl_font_render_blended__doc__ },
	{ "render_solid", sdl_font_render_solid, 1,
		sdl_font_render_solid__doc__ },
	{ "render_utf8", sdl_font_render_utf8, 1, sdl_font_render_utf8__doc__ },
	{ "render_utf8_blended", sdl_font_render_utf8_blended, 1,
		sdl_font_render_utf8_blended__doc__ },
	{ "render_utf8_solid", sdl_font_render_utf8_solid, 1,
		sdl_font_render_utf8_solid__doc__ },
	{ "get_style", sdl_font_get_style, 1, sdl_font_get_style__doc__ },
	{ "set_style", sdl_font_set_style, 1, sdl_font_set_style__doc__ },
	{ "get_descent", sdl_font_get_descent, 1, sdl_font_get_descent__doc__ },
	{ "get_skip", sdl_font_get_skip, 1, sdl_font_get_skip__doc__ },
	{ "get_text_size", sdl_font_get_text_size, 1,
		sdl_font_get_text_size__doc__ },
	{ "get_utf8_size", sdl_font_get_utf8_size, 1,
		sdl_font_get_utf8_size__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_cd__builtins__[] =
{
	{ "play_tracks", sdl_cd_play_tracks, 1, sdl_cd_play_tracks__doc__ },
	{ "play", sdl_cd_play, 1, sdl_cd_play__doc__ },
	{ "pause", sdl_cd_pause, 1, sdl_cd_pause__doc__ },
	{ "resume", sdl_cd_resume, 1, sdl_cd_resume__doc__ },
	{ "stop", sdl_cd_stop, 1, sdl_cd_stop__doc__ },
	{ "eject", sdl_cd_eject, 1, sdl_cd_eject__doc__ },
	{ "get_status", sdl_cd_get_status, 1, sdl_cd_get_status__doc__ },
	{ "get_cur_track", sdl_cd_get_cur_track, 1, sdl_cd_get_cur_track__doc__ },
	{ "get_cur_frame", sdl_cd_get_cur_frame, 1, sdl_cd_get_cur_frame__doc__ },
	{ "has_cd", sdl_cd_has_cd, 1, sdl_cd_has_cd__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_active_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ "get_gain", sdl_event_active_get_gain, 1,
		sdl_event_active_get_gain__doc__ },
	{ "set_gain", sdl_event_active_set_gain, 1,
		sdl_event_active_set_gain__doc__ },
	{ "get_state", sdl_event_active_get_state, 1,
		sdl_event_active_get_state__doc__ },
	{ "set_state", sdl_event_active_set_state, 1,
		sdl_event_active_set_state__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_keyboard_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ "get_sym", sdl_event_key_get_sym, 1, sdl_event_key_get_sym__doc__ },
	{ "set_sym", sdl_event_key_set_sym, 1, sdl_event_key_set_sym__doc__ },
	{ "get_mod", sdl_event_key_get_mod, 1, sdl_event_key_get_mod__doc__ },
	{ "set_mod", sdl_event_key_set_mod, 1, sdl_event_key_set_mod__doc__ },
	{ "get_state", sdl_event_key_get_state, 1, sdl_event_key_get_state__doc__ },
	{ "set_state", sdl_event_key_set_state, 1, sdl_event_key_set_state__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_mouse_motion_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ "get_coords", sdl_event_mouse_get_coords, 1,
		sdl_event_mouse_get_coords__doc__ },
	{ "set_coords", sdl_event_mouse_set_coords, 1,
		sdl_event_mouse_set_coords__doc__ },
	{ "get_state", sdl_event_mouse_get_state, 1,
		sdl_event_mouse_get_state__doc__ },
	{ "set_state", sdl_event_mouse_set_state, 1,
		sdl_event_mouse_set_state__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_mouse_button_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ "get_state", sdl_event_button_get_state, 1,
		sdl_event_button_get_state__doc__ },
	{ "set_state", sdl_event_button_set_state, 1,
		sdl_event_button_set_state__doc__ },
	{ "get_button", sdl_event_button_get_button, 1,
		sdl_event_button_get_button__doc__ },
	{ "set_button", sdl_event_button_set_button, 1,
		sdl_event_button_set_button__doc__ },
	{ "get_coords", sdl_event_button_get_coords, 1,
		sdl_event_button_get_coords__doc__ },
	{ "set_coords", sdl_event_button_set_coords, 1,
		sdl_event_button_set_coords__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_joy_axis_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ "get_ids", sdl_event_joy_axis_get_ids, 1,
		sdl_event_joy_axis_get_ids__doc__ },
	{ "get_state", sdl_event_joy_axis_get_state, 1, 
		sdl_event_joy_axis_get_state__doc__ },
	{ "set_ids", sdl_event_joy_axis_set_ids, 1,
		sdl_event_joy_axis_set_ids__doc__ },
	{ "set_state", sdl_event_joy_axis_set_state, 1,
		sdl_event_joy_axis_set_state__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_joy_ball_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ "get_ids", sdl_event_joy_ball_get_ids, 1,
		sdl_event_joy_ball_get_ids__doc__ },
	{ "set_ids", sdl_event_joy_ball_set_ids, 1,
		sdl_event_joy_ball_set_ids__doc__ },
	{ "get_coords", sdl_event_joy_ball_get_coords, 1,
		sdl_event_joy_ball_get_coords__doc__ },
	{ "set_coords", sdl_event_joy_ball_set_coords, 1,
		sdl_event_joy_ball_set_coords__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_joy_hat_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ "get_ids", sdl_event_joy_hat_get_ids, 1,
		sdl_event_joy_hat_get_ids__doc__ },
	{ "set_ids", sdl_event_joy_hat_set_ids, 1,
		sdl_event_joy_hat_set_ids__doc__ }, 
	{ "get_pos", sdl_event_joy_hat_get_pos, 1,
		sdl_event_joy_hat_get_pos__doc__ },
	{ "set_pos", sdl_event_joy_hat_set_pos, 1,
		sdl_event_joy_hat_set_pos__doc__ },
	{ NULL, NULL }  
};

static PyMethodDef sdl_joy_button_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ "get_ids", sdl_event_jbutton_get_ids, 1,
		sdl_event_jbutton_get_ids__doc__ },
	{ "set_ids", sdl_event_jbutton_set_ids, 1,
		sdl_event_jbutton_set_ids__doc__ },
	{ "get_state", sdl_event_jbutton_get_state, 1,
		sdl_event_jbutton_get_state__doc__ },
	{ "set_state", sdl_event_jbutton_set_state, 1,
		sdl_event_jbutton_set_state__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_resize_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ "get_width", sdl_event_resize_get_width, 1,
		sdl_event_resize_get_width__doc__ },
	{ "get_height", sdl_event_resize_get_height, 1,
		sdl_event_resize_get_height__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_event__builtins__[] =
{
	{ "get_type", sdl_event_get_type, 1, sdl_event_get_type__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_joy__builtins__[] =
{
	{ "get_id", sdl_joy_get_id, 1, sdl_joy_get_id__doc__ },
	{ "get_axes", sdl_joy_get_axes, 1, sdl_joy_get_axes__doc__ },
	{ "get_balls", sdl_joy_get_balls, 1, sdl_joy_get_balls__doc__ },
	{ "get_hats", sdl_joy_get_hats, 1, sdl_joy_get_hats__doc__ },
	{ "get_buttons", sdl_joy_get_buttons, 1, sdl_joy_get_buttons__doc__ },
	{ "get_axis", sdl_joy_get_axis, 1, sdl_joy_get_axis__doc__ },
	{ "get_hat", sdl_joy_get_hat, 1, sdl_joy_get_hat__doc__ },
	{ "get_button", sdl_joy_get_button, 1, sdl_joy_get_button__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_audiodev__builtins__[] =
{
	{ "play", sdl_audiodev_play, 1, sdl_audiodev_play__doc__ },
	{ "play_music", sdl_audiodev_play_music, 1,
		sdl_audiodev_play_music__doc__ },
	{ "alloc_channels", sdl_audiodev_alloc_channels, 1,
		sdl_audiodev_alloc_channels__doc__ },
	{ "set_volume", sdl_audiodev_set_volume, 1,
		sdl_audiodev_set_volume__doc__ },
	{ "get_volume", sdl_audiodev_get_volume, 1,
		sdl_audiodev_get_volume__doc__ },
	{ "set_music_volume", sdl_audiodev_set_music_volume, 1,
		sdl_audiodev_set_music_volume__doc__ },
	{ "get_music_volume", sdl_audiodev_get_music_volume, 1,
		sdl_audiodev_get_music_volume__doc__ },
	{ "fade_in", sdl_audiodev_fade_in, 1, sdl_audiodev_fade_in__doc__ },
	{ "fade_in_music", sdl_audiodev_fade_in_music, 1,
		sdl_audiodev_fade_in_music__doc__ },
	{ "fade_out", sdl_audiodev_fade_out, 1, sdl_audiodev_fade_out__doc__ },
	{ "fade_out_music", sdl_audiodev_fade_out_music, 1,
		sdl_audiodev_fade_out_music__doc__ },
	{ "halt", sdl_audiodev_halt, 1, sdl_audiodev_halt__doc__ },
	{ "halt_music", sdl_audiodev_halt_music, 1, sdl_audiodev_halt_music__doc__ },
	{ "expire", sdl_audiodev_expire, 1, sdl_audiodev_expire__doc__ },
	{ "pause", sdl_audiodev_pause, 1, sdl_audiodev_pause__doc__ },
	{ "pause_music", sdl_audiodev_pause_music, 1,
		sdl_audiodev_pause_music__doc__ },
	{ "resume", sdl_audiodev_resume, 1, sdl_audiodev_resume__doc__ },
	{ "resume_music", sdl_audiodev_resume_music, 1,
		sdl_audiodev_resume_music__doc__ },
	{ "rewind_music", sdl_audiodev_rewind_music, 1,
		sdl_audiodev_rewind_music__doc__ },
	{ "is_paused", sdl_audiodev_is_paused, 1,
		sdl_audiodev_is_paused__doc__ },
	{ "is_music_paused", sdl_audiodev_is_music_paused, 1,
		sdl_audiodev_is_music_paused__doc__ },
	{ "is_playing", sdl_audiodev_is_playing, 1, 
		sdl_audiodev_is_playing__doc__ },
	{ "is_music_playing", sdl_audiodev_is_music_playing, 1,
		sdl_audiodev_is_music_playing__doc__ },
	{ "fading", sdl_audiodev_fading, 1, sdl_audiodev_fading__doc__ },
	{ "fading_music", sdl_audiodev_fading_music, 1,
			sdl_audiodev_fading_music__doc__ },
	{ "get_freq", sdl_audiodev_get_freq, 1, sdl_audiodev_get_freq__doc__ },
	{ "get_format", sdl_audiodev_get_format, 1,
		sdl_audiodev_get_format__doc__ },
	{ "get_channels", sdl_audiodev_get_channels, 1,
		sdl_audiodev_get_channels__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_sound__builtins__[] =
{
	{ "get_len", sdl_sound_get_len, 1, sdl_sound_get_len__doc__ },
	{ "set_volume", sdl_sound_set_volume, 1, sdl_sound_set_volume__doc__ },
	{ "get_volume", sdl_sound_get_volume, 1, sdl_sound_get_volume__doc__ },
	{ NULL, NULL }
};

static PyMethodDef sdl_music__builtins__[] =
{
	{ NULL, NULL }
};

typedef struct
{
	PyObject_HEAD
	SDL_Surface* surf;
} Surface_Object;

static PyTypeObject Surface_Type =
{
	PyObject_HEAD_INIT(NULL)
	0,
	"Surface",
	sizeof(Surface_Object),
	0,
	sdl_surface_dealloc,
	0,
	sdl_surface_getattr,
	0,
	0,
	0,
	0,
	&sdl_surface_as_sequence,
	0,
	0,
	0
	
};

typedef struct
{
	PyObject_HEAD
	TTF_Font* font;
} Font_Object;

static PyTypeObject Font_Type = 
{
	PyObject_HEAD_INIT(NULL)
	0,
	"Font",
	sizeof(Font_Object),
	0,
	sdl_font_dealloc,	
	0,
	sdl_font_getattr
};

typedef struct
{
	PyObject_HEAD
	SDL_CD* cd;
} CD_Object;

static PyTypeObject CD_Type =
{
	PyObject_HEAD_INIT(NULL)
	0,
	"CD",
	sizeof(CD_Object),
	0,
	sdl_cd_dealloc,
	0,
	sdl_cd_getattr,
	0,
	0,
	0,
	0,
	&sdl_cd_as_sequence,
	0
};

typedef struct
{
	PyObject_HEAD
	SDL_Event* event;
} Event_Object;

static PyTypeObject Event_Type =
{
	PyObject_HEAD_INIT(NULL)
	0,
	"Event",
	sizeof(Event_Object),
	0,
	sdl_event_dealloc,
	0,
	sdl_event_getattr
};

typedef struct
{
	PyObject_HEAD
	SDL_Joystick* joy;
} Joystick_Object;

static PyTypeObject Joystick_Type =
{
	PyObject_HEAD_INIT(NULL)
	0,
	"Joystick",
	sizeof(Joystick_Object),
	0,
	sdl_joy_dealloc,
	0,
	sdl_joy_getattr
};

typedef struct
{
	PyObject_HEAD
	int freq;
	Uint16 format;
	int channels;
} AudioDev_Object;


/* Mostly the same as a AudioBuf, except we use a different constructor and
 * destructor
*/
static PyTypeObject AudioDev_Type =
{
	PyObject_HEAD_INIT(NULL)
	0,
	"AudioDev",
	sizeof(AudioDev_Object),
	0,
	sdl_audiodev_dealloc,
	0,
	sdl_audiodev_getattr
};

typedef struct
{
	PyObject_HEAD
	Mix_Chunk* sound;
} Sound_Object;

static PyTypeObject Sound_Type =
{
	PyObject_HEAD_INIT(NULL)
	0,
	"Sound",
	sizeof(Sound_Object),
	0,
	sdl_sound_dealloc,
	0,
	sdl_sound_getattr
};

typedef struct
{
	PyObject_HEAD
	Mix_Music* music;
} Music_Object;

static PyTypeObject Music_Type =
{
	PyObject_HEAD_INIT(NULL)
	0,
	"Music",
	sizeof(Music_Object),
	0,
	sdl_music_dealloc,
	0,
	sdl_music_getattr
};


/* This is an internal object, and is not accessible externally */
typedef struct
{
	SDL_RWops rw;
	PyObject* obj;
	PyObject* seek;
	PyObject* tell;
	PyObject* read;
	PyObject* write;
	PyObject* close;
} RW_Object;

static RW_Object* rw_NEW(PyObject* src_obj, char* mode);
static void rw_DEL(RW_Object* rw_ref);
static int rw_seek(SDL_RWops* context, int offset, int whence);
static int rw_read(SDL_RWops* context, void* ptr, int size, int maxnum);
static int rw_write(SDL_RWops* context, const void* ptr, int size, int maxnum);
static int rw_close(SDL_RWops* context);

static int sdl_is_initialized = 0;
static int video_is_initialized = 0;
static int cdrom_is_initialized = 0;
static int joy_is_initialized = 0;
static int audio_is_initialized = 0;
static int audio_is_open = 0;
